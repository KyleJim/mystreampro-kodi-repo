"""XiaobaoTV catalogue provider; independent of the frozen Olevod provider."""

import re
import time
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse, quote
from urllib.request import Request, urlopen

BASE_URL = "https://www.xiaobaotv.tv"
MOVIE_GENRES = {
    "action": (101, "动作"), "comedy": (102, "喜剧"),
    "romance": (103, "爱情"), "sci_fi": (104, "科幻"),
    "drama": (105, "剧情"), "horror": (108, "恐怖"),
    "war": (114, "战争"), "animation": (115, "动画"),
    "documentary": (119, "纪录"),
}
MOVIE_REGIONS = (
    "中国香港", "中国大陆", "中国台湾", "美国", "日本", "韩国",
    "英国", "法国", "德国", "泰国", "印度", "其他",
)


_FILTERS_LOADED_AT = 0
_FILTERS_CACHE_SECONDS = 3600

def load_movie_filters():
    """Refresh both movie filters from the provider catalogue, with fallback."""
    global _FILTERS_LOADED_AT, MOVIE_REGIONS
    if time.monotonic() - _FILTERS_LOADED_AT < _FILTERS_CACHE_SECONDS:
        return
    from .movie_filters import parse_filters
    try:
        request = Request(BASE_URL + "/movie/type/1.html", headers={"User-Agent": "Mozilla/5.0"})
        with urlopen(request, timeout=12) as response:
            if urlparse(response.geturl()).hostname != urlparse(BASE_URL).hostname:
                raise ValueError("Unexpected movie filter redirect")
            markup = response.read().decode("utf-8", errors="replace")
        genres, regions = parse_filters(markup, "xiaobao")
        if not genres or not regions:
            raise ValueError("Movie filter menu missing")
        old_genres = dict(MOVIE_GENRES)
        MOVIE_GENRES.clear()
        for genre_id, label in genres:
            key = next((key for key, (id_value, _) in old_genres.items()
                        if id_value == int(genre_id)), "web_" + genre_id)
            MOVIE_GENRES[key] = (int(genre_id), label)
        MOVIE_REGIONS = tuple(regions)
        _FILTERS_LOADED_AT = time.monotonic()
    except Exception:
        # Keep the last successful options (or original built-in fallback).
        _FILTERS_LOADED_AT = time.monotonic() - _FILTERS_CACHE_SECONDS + 120


TV_GENRES = {
    'tv_all': (2, '全部'),
    'tv_china': (201, '国产剧'), 'tv_hongkong': (202, '香港剧'),
    'tv_taiwan': (203, '台湾剧'), 'tv_korea': (204, '韩国剧'),
    'tv_japan': (205, '日本剧'), 'tv_thailand': (206, '泰国剧'),
    'tv_western': (207, '欧美剧'), 'tv_overseas': (208, '海外剧'),
}
TV_REGIONS = tuple(list(MOVIE_REGIONS))
_TV_FILTERS_LOADED_AT = 0


def load_tv_filters():
    """Use the TV catalogue's own filter options, never movie options."""
    global _TV_FILTERS_LOADED_AT, TV_REGIONS
    if time.monotonic() - _TV_FILTERS_LOADED_AT < _FILTERS_CACHE_SECONDS:
        return
    from .movie_filters import parse_filters
    try:
        request = Request(BASE_URL + '/movie/type/2.html',
                          headers={'User-Agent': 'Mozilla/5.0'})
        with urlopen(request, timeout=12) as response:
            if urlparse(response.geturl()).hostname != urlparse(BASE_URL).hostname:
                raise ValueError('Unexpected Xiaobao TV filter redirect')
            markup = response.read().decode('utf-8', errors='replace')
        genres, regions = parse_filters(markup, 'xiaobao')
        if not genres or not regions:
            raise ValueError('TV filter menu missing')
        old = dict(TV_GENRES)
        updated = {'tv_all': (2, '全部')}
        for genre_id, label in genres:
            key = next((k for k, (number, _) in old.items()
                        if number == int(genre_id)), 'tv_web_' + genre_id)
            updated[key] = (int(genre_id), label)
        TV_GENRES.clear()
        TV_GENRES.update(updated)
        TV_REGIONS = tuple(regions)
        _TV_FILTERS_LOADED_AT = time.monotonic()
    except Exception:
        _TV_FILTERS_LOADED_AT = time.monotonic() - _FILTERS_CACHE_SECONDS + 120


def get_dramas(category='tv_all', page=1, region=None):
    """TV series use the same catalogue markup and player as Xiaobao movies."""
    if category not in TV_GENRES:
        raise ValueError('Unknown Xiaobao TV genre')
    if page < 1:
        raise ValueError('Invalid page')
    category_id = TV_GENRES[category][0]
    area = '/area/' + quote(region, safe='') if region else ''
    url = f'{BASE_URL}/movie/show/{category_id}{area}/page/{page}.html'
    request = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urlopen(request, timeout=15) as response:
        if urlparse(response.geturl()).hostname != urlparse(BASE_URL).hostname:
            raise ValueError('Unexpected Xiaobao TV redirect')
        markup = response.read().decode('utf-8', errors='replace')
    parser = CatalogueParser()
    parser.feed(markup)
    return parser.movies


class CatalogueParser(HTMLParser):
    """Parse Xiaobao catalogue cards from their poster anchor attributes.

    Poster artwork is a CSS background on an anchor, not a nested img tag.
    The card's year and video-source label are separate span elements.
    """

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.movies = []
        self._seen = set()
        self._current = None
        self._anchor_depth = 0
        self._tag_stack = []
        self._capture = None
        self._capture_depth = 0
        self._captured_text = []

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        classes = attributes.get("class", "").split()
        if tag == "a" and "myui-vodlist__thumb" in classes:
            href = attributes.get("href", "")
            if re.fullmatch(r"(?:https?://[^/]+)?/movie/detail/\d+\.html", href):
                image = attributes.get("data-original", "").strip()
                if not image:
                    image = attributes.get("data-src", "").strip()
                if not image:
                    style = attributes.get("style", "")
                    match = re.search(r"background-image\s*:\s*url\(\s*['\"]?([^'\")]+)", style)
                    if match:
                        image = match.group(1).strip()
                self._current = {
                    "title": attributes.get("title", "") or attributes.get("alt", ""),
                    "url": urljoin(BASE_URL, href),
                    "image": urljoin(BASE_URL, image) if image and not image.startswith(("data:", "javascript:")) else "",
                    "rating": "", "quality": "", "year": "",
                }
                self._anchor_depth = len(self._tag_stack) + 1
        if self._current and tag == "span":
            if "pic-text" in classes:
                self._capture = "quality"
            elif "tag" in classes and "pic-tag" not in classes:
                self._capture = "year"
            if self._capture:
                self._capture_depth = len(self._tag_stack) + 1
                self._captured_text = []
        if tag not in {"img", "br", "hr", "meta", "input", "link", "source", "wbr"}:
            self._tag_stack.append(tag)

    def handle_data(self, data):
        if self._capture:
            self._captured_text.append(data)

    def handle_endtag(self, tag):
        depth = len(self._tag_stack)
        if tag == "span" and self._capture and depth == self._capture_depth:
            value = " ".join(" ".join(self._captured_text).split())
            if self._current:
                self._current[self._capture] = value
            self._capture = None
        if tag == "a" and self._current and depth == self._anchor_depth:
            if self._current["title"] and self._current["url"] not in self._seen:
                self.movies.append(self._current)
                self._seen.add(self._current["url"])
            self._current = None
            self._capture = None
        if tag in self._tag_stack:
            while self._tag_stack:
                if self._tag_stack.pop() == tag:
                    break


def get_movies(genre=None, page=1, region=None):
    """Fetch one Xiaobao movie catalogue page using verified show routes."""
    if genre is not None and genre not in MOVIE_GENRES:
        raise ValueError("Unknown Xiaobao movie genre")
    if page < 1:
        raise ValueError("Invalid page number")
    category_id = MOVIE_GENRES[genre][0] if genre else 1
    area = "/area/" + quote(region, safe="") if region else ""
    url = f"{BASE_URL}/movie/show/{category_id}{area}/page/{page}.html"
    request = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(request, timeout=15) as response:
        final_url = response.geturl()
        if urlparse(final_url).hostname != "www.xiaobaotv.tv":
            raise ValueError("Unexpected Xiaobao redirect")
        content = response.read().decode("utf-8", errors="replace")
    parser = CatalogueParser()
    parser.feed(content)
    return parser.movies


class MovieDetailParser(HTMLParser):
    """Extract the visible metadata from a Xiaobao movie detail block."""

    FIELD_NAMES = {"分类": "genre", "地区": "region", "年份": "year",
                   "更新": "update", "主演": "cast", "导演": "director",
                   "简介": "plot"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.details = {key: "" for key in
                        ("title", "genre", "region", "year", "quality",
                         "updated", "cast", "director", "plot")}
        self._inside = False
        self._depth = 0
        self._capture = None
        self._capture_depth = 0
        self._text = []

    def handle_starttag(self, tag, attrs):
        classes = dict(attrs).get("class", "").split()
        if not self._inside and tag == "div" and "myui-content__detail" in classes:
            self._inside = True
            self._depth = 1
            return
        if not self._inside:
            return
        if tag == "div":
            self._depth += 1
        if self._capture is None:
            if tag == "h1" and "title" in classes:
                self._capture = "title"
            elif tag == "p" and "data" in classes:
                self._capture = "paragraph"
            if self._capture:
                self._capture_depth = 1
                self._text = []
        elif tag not in {"img", "br", "hr", "input", "meta"}:
            self._capture_depth += 1
        if self._capture and tag == "br":
            self._text.append(" ")

    def handle_data(self, data):
        if self._inside and self._capture:
            self._text.append(data)

    def handle_endtag(self, tag):
        if not self._inside:
            return
        if self._capture:
            self._capture_depth -= 1
            if self._capture_depth == 0:
                value = " ".join(" ".join(self._text).split())
                if self._capture == "title":
                    self.details["title"] = value
                elif self._capture == "paragraph":
                    for chinese, key in self.FIELD_NAMES.items():
                        if value.startswith(chinese + "：") or value.startswith(chinese + ":"):
                            result = value[len(chinese) + 1:].strip()
                            if key == "update":
                                quality, separator, updated = result.partition("/")
                                self.details["quality"] = quality.strip()
                                self.details["updated"] = updated.strip() if separator else ""
                            elif key == "plot":
                                # The short synopsis may end in a detail-link label.
                                self.details[key] = re.sub(r"\s*详情\s*$", "", result).strip()
                            elif key == "genre":
                                # Genre, region and year share one <p> on Xiaobao.
                                parts = re.split(r"\s*(地区|年份)[：:]\s*", result)
                                self.details["genre"] = parts[0].strip()
                                for index in range(1, len(parts) - 1, 2):
                                    field = "region" if parts[index] == "地区" else "year"
                                    self.details[field] = parts[index + 1].strip()
                            else:
                                self.details[key] = result
                            break
                self._capture = None
        if tag == "div":
            self._depth -= 1
            if self._depth == 0:
                self._inside = False


def get_movie_details(url):
    """Fetch a selected Xiaobao movie's metadata without loading player links."""
    parsed = urlparse(url)
    if (parsed.scheme != "https" or parsed.hostname != "www.xiaobaotv.tv"
            or not re.fullmatch(r"/movie/detail/\d+\.html", parsed.path)):
        raise ValueError("Unexpected Xiaobao detail URL")
    request = Request(url, headers={"User-Agent": "Mozilla/5.0",
                                    "Referer": BASE_URL + "/"})
    with urlopen(request, timeout=15) as response:
        if urlparse(response.geturl()).hostname != "www.xiaobaotv.tv":
            raise ValueError("Unexpected Xiaobao redirect")
        source = response.read().decode("utf-8", errors="replace")
    parser = MovieDetailParser()
    parser.feed(source)
    return parser.details


class PlaybackPanelParser(HTMLParser):
    """Collect source headings and entry links from playback panels."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.sources = []
        self._depth = 0
        self._panel_depth = None
        self._heading_depth = None
        self._heading = []
        self._entry_depth = None
        self._entry = None

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        classes = attributes.get('class', '').split()
        self._depth += 1
        if tag == 'div' and 'myui-panel' in classes and self._panel_depth is None:
            self._panel_depth = self._depth
            self.sources.append({'name': '', 'entries': []})
        if self._panel_depth is None:
            return
        if tag == 'h3' and 'title' in classes:
            self._heading_depth = self._depth
            self._heading = []
        if tag == 'a' and re.fullmatch(r'/movie/play/\d+-\d+-\d+\.html',
                                        attributes.get('href', '')):
            self._entry_depth = self._depth
            self._entry = {'label': '', 'url': urljoin(BASE_URL, attributes['href'])}

    def handle_data(self, data):
        if self._heading_depth is not None:
            self._heading.append(data)
        if self._entry is not None:
            self._entry['label'] += data

    def handle_endtag(self, tag):
        if tag == 'h3' and self._heading_depth == self._depth and self.sources:
            self.sources[-1]['name'] = ' '.join(''.join(self._heading).split())
            self._heading_depth = None
        if tag == 'a' and self._entry_depth == self._depth and self._entry:
            self._entry['label'] = ' '.join(self._entry['label'].split())
            if self._entry['label']:
                self.sources[-1]['entries'].append(self._entry)
            self._entry = None
            self._entry_depth = None
        if tag == 'div' and self._panel_depth == self._depth:
            self._panel_depth = None
        self._depth = max(0, self._depth - 1)


def _fetch_html(url, expected_path):
    """Fetch a verified Xiaobao page without following off-site redirects."""
    parsed = urlparse(url)
    if parsed.scheme != 'https' or parsed.hostname != 'www.xiaobaotv.tv' or not re.fullmatch(expected_path, parsed.path):
        raise ValueError('Unexpected Xiaobao URL')
    request = Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Referer': BASE_URL + '/'})
    with urlopen(request, timeout=15) as response:
        final = urlparse(response.geturl())
        if final.scheme != 'https' or final.hostname != 'www.xiaobaotv.tv':
            raise ValueError('Unexpected Xiaobao redirect')
        return response.read().decode('utf-8', errors='replace')


def get_movie_versions(url):
    """Return supported Xiaobao movie versions, preferring bilingual R."""
    source = _fetch_html(url, r'/movie/detail/\d+\.html')
    parser = PlaybackPanelParser()
    parser.feed(source)
    panels = [panel for panel in parser.sources if panel['entries']]
    r_panels = [panel for panel in panels if 'Ⓡ' in panel['name']]
    i_panels = [panel for panel in panels if 'Ⓘ' in panel['name']]
    # D is excluded because it was observed to fail on the test site.
    preferred = r_panels if r_panels else i_panels
    if not preferred:
        return []
    versions = [dict(title=entry['label'], url=entry['url'])
                for panel in preferred for entry in panel['entries']]
    return versions


def get_stream_url(url):
    """Resolve the selected Xiaobao player page to a media URL.

    The site embeds JSON in a player_aaaa JavaScript assignment. Some pages
    omit the trailing semicolon, so don't require one in the match.
    """
    import base64
    import json
    from urllib.parse import unquote

    source = _fetch_html(url, r'/movie/play/\d+-\d+-\d+\.html')
    match = re.search(r'\bplayer_aaaa\s*=\s*(\{.*?\})\s*(?:;|</script)',
                      source, re.DOTALL | re.IGNORECASE)
    if not match:
        # Avoid logging the page itself or leaking stream credentials.
        if 'player_aaaa' in source:
            raise ValueError('Xiaobao player data could not be parsed')
        if 'captcha' in source.lower() or 'cloudflare' in source.lower():
            raise ValueError('Xiaobao blocked the player page')
        raise ValueError('Xiaobao player configuration missing (page has no player_aaaa)')
    try:
        data = json.loads(match.group(1))
        value = data.get('url', '')
        encryption = int(data.get('encrypt', 0))
        if encryption == 1:
            value = unquote(value)
        elif encryption == 2:
            value = unquote(base64.b64decode(value).decode('utf-8'))
        elif encryption != 0:
            raise ValueError('Unsupported Xiaobao stream encoding')
    except (json.JSONDecodeError, TypeError, UnicodeDecodeError) as exc:
        raise ValueError('Invalid Xiaobao player data') from exc
    parsed = urlparse(value)
    if parsed.scheme not in ('https', 'http') or not parsed.hostname:
        raise ValueError('Invalid Xiaobao stream URL')
    return value
