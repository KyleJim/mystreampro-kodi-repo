"""Standalone experimental Kodi window for highlight-triggered metadata.

No MyStreamPro test-m.2 files, caches, or add-on IDs are modified.
"""
import html
import gzip
import hashlib
import os
import re
import sqlite3
import sys
import threading
import time
import json
from urllib.parse import parse_qs, urlencode
from urllib.request import Request, urlopen
from html.parser import HTMLParser

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.episode_sort import newest_first
from resources.lib.providers import olevod, xiaobao
from resources.lib import live_tv
from resources.lib import playback_snapshot

ADDON = xbmcaddon.Addon()
OLEVOD_CATEGORIES = {
    'latest': '全部',
    'china': '国产剧', 'western': '欧美剧',
    'hk_taiwan': '港台剧', 'japan_korea': '日韩剧', 'short': '短剧',
}

HANDLE = int(sys.argv[1])
ACTIONS_MOVE = {1, 2, 3, 4, 5, 6, 7}
ACTIONS_BACK = {9, 10, 92}


def _snapshot_profile():
    """Return the shared add-on profile directory."""
    return xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))


def _read_snapshot():
    """Read optional playback state; never block ordinary navigation."""
    try:
        return playback_snapshot.load(
            _snapshot_profile(), playback_snapshot.SESSION_ID)
    except (OSError, ValueError, TypeError, sqlite3.Error) as exc:
        xbmc.log('MyStreamPro snapshot read: %s' % exc, xbmc.LOGWARNING)
        return None


def _save_snapshot(snapshot):
    """Save playback state without interrupting video if storage fails."""
    try:
        playback_snapshot.save(
            _snapshot_profile(), playback_snapshot.SESSION_ID, snapshot)
    except (OSError, ValueError, TypeError, sqlite3.Error) as exc:
        xbmc.log('MyStreamPro snapshot save: %s' % exc, xbmc.LOGWARNING)


def _discard_snapshot():
    """Release the snapshot when the restored poster browser is exited."""
    try:
        playback_snapshot.delete(
            _snapshot_profile(), playback_snapshot.SESSION_ID)
    except (OSError, ValueError, sqlite3.Error) as exc:
        xbmc.log('MyStreamPro snapshot delete: %s' % exc, xbmc.LOGWARNING)


class DetailParser(HTMLParser):
    """Extract Olevod HTML meta description without loading scripts."""

    def __init__(self):
        super().__init__()
        self.description = ""

    def handle_starttag(self, tag, attrs):
        if tag == "meta":
            attributes = dict(attrs)
            if attributes.get("name", "").lower() == "description":
                self.description = attributes.get("content", "")


def clean_region(value):
    """Remove URL suffixes from region names, including old cached values."""
    return re.sub(r"(?:\.html?)+$", "", (value or "").strip(), flags=re.I)


def get_details(url):
    """Retrieve a selected movie's year and synopsis only on highlight."""
    source = olevod.fetch_html(url, timeout=8)
    match = re.search(r"/vod/search/year/(19\d{2}|20\d{2})\.html", source)
    if not match:
        match = re.search(r"年份[：:]?\s*</span>\s*<a[^>]*>\s*"
                          r"(19\d{2}|20\d{2})", source)
    parser = DetailParser()
    parser.feed(source)
    description = html.unescape(parser.description).strip()
    description = re.sub(r"^.*?剧情[:：]\s*", "", description)
    region_match = re.search(
        r'(?:/vod/search/area/|/vod/show/area/)([^"<>/]+)', source)
    region = ""
    if region_match:
        from urllib.parse import unquote
        region = clean_region(html.unescape(unquote(region_match.group(1))))
    if not region:
        region_match = re.search(
            r'(?:地区|地區|国家|國家|产地|產地)\s*[：:]?\s*</span>\s*'
            r'(?:<a[^>]*>)?\s*([^<\s]{2,16})', source)
        if region_match:
            region = clean_region(html.unescape(region_match.group(1)))
    return {"year": match.group(1) if match else "Unknown",
            "plot": description or "No synopsis available.",
            "region": region}


def cache_connection():
    """Open a private SQLite database for this prototype."""
    folder = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    os.makedirs(folder, exist_ok=True)
    connection = sqlite3.connect(os.path.join(folder, "details.sqlite3"),
                                 timeout=5)
    connection.execute("CREATE TABLE IF NOT EXISTS details "
                       "(url TEXT PRIMARY KEY, year TEXT, plot TEXT)")
    columns = {row[1] for row in connection.execute("PRAGMA table_info(details)")}
    if "region" not in columns:
        connection.execute("ALTER TABLE details ADD COLUMN region TEXT DEFAULT ''")
    return connection


def cached_detail(url):
    """Read cached metadata, or return None."""
    with cache_connection() as connection:
        row = connection.execute(
            "SELECT year, plot, region FROM details WHERE url=?", (url,)
        ).fetchone()
    return {"year": row[0], "plot": row[1], "region": clean_region(row[2])} if row else None


def store_detail(url, details):
    """Persist fetched metadata for later highlights."""
    with cache_connection() as connection:
        connection.execute(
            "INSERT OR REPLACE INTO details(url,year,plot,region) VALUES(?,?,?,?)",
            (url, details["year"], details["plot"], clean_region(details.get("region", ""))),
        )


def cached_poster(url):
    """Find a previously downloaded poster without accessing the network."""
    if not url:
        return ""
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    folder = os.path.join(profile, "posters")
    digest = hashlib.sha256(url.encode("utf-8")).hexdigest()
    for ext in (".webp", ".jpg", ".png"):
        path = os.path.join(folder, digest + ext)
        if os.path.isfile(path) and os.path.getsize(path) > 32:
            return path
    return ""


def poster_for(url):
    """Download selected artwork locally, using its actual image format."""
    if not url or not url.startswith("https://"):
        return ""
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    folder = os.path.join(profile, "posters")
    os.makedirs(folder, exist_ok=True)
    digest = hashlib.sha256(url.encode("utf-8")).hexdigest()
    for ext in (".webp", ".jpg", ".png"):
        path = os.path.join(folder, digest + ext)
        if os.path.isfile(path) and os.path.getsize(path) > 32:
            return path
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0",
        "Referer": ("https://ibaotv.com/" if "ibaotv.com" in url
                    else "https://www.olehdtv.com/"),
        "Accept-Encoding": "identity",
    })
    with urlopen(request, timeout=6) as response:
        data = response.read(5 * 1024 * 1024 + 1)
        encoding = response.headers.get("Content-Encoding", "")
    if len(data) > 5 * 1024 * 1024:
        return ""
    if "gzip" in encoding.lower() or data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data)
    if len(data) > 5 * 1024 * 1024:
        return ""
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        ext = ".webp"
    elif data.startswith(b"\xff\xd8\xff"):
        ext = ".jpg"
    elif data.startswith(b"\x89PNG\r\n\x1a\n"):
        ext = ".png"
    else:
        return ""
    path = os.path.join(folder, digest + ext)
    temp = path + ".tmp"
    with open(temp, "wb") as output:
        output.write(data)
    os.replace(temp, path)
    return path


class MovieDetails(xbmcgui.WindowXMLDialog):
    """Non-blocking detail window; updates visible metadata after fetch."""

    def __init__(self, *args, **kwargs):
        self.movie = kwargs.pop('movie')
        super().__init__(*args, **kwargs)
        self.want_play = False
        self.dismissed = False
        self.want_play = False

    def onInit(self):
        movie = self.movie
        self.setProperty('title', movie.get('title', ''))
        self.setProperty('rating', '%s/10' % movie['rating'] if movie.get('rating') else '')
        self.setProperty('quality', movie.get('quality', ''))
        self.setProperty('year', '')
        self.setProperty('region', '')
        self.setProperty('plot', 'Loading movie information...')
        self.setProperty('loading', 'Loading details...')
        poster = cached_poster(movie.get('image', ''))
        self.setProperty('poster', poster)
        threading.Thread(target=self._fetch, daemon=True).start()

    def _fetch(self):
        movie = self.movie
        details = None
        try:
            details = cached_detail(movie['url'])
            # Cached data may be incomplete; refresh once when required.
            if not details or not details.get('year') or not details.get('region'):
                try:
                    fetched = get_details(movie['url'])
                    if fetched:
                        details = fetched
                        store_detail(movie['url'], fetched)
                except (OSError, ValueError, UnicodeError, sqlite3.Error) as exc:
                    xbmc.log('MyStreamPro M4.7 detail fetch: %s' % exc, xbmc.LOGWARNING)
            if not self.dismissed:
                self.setProperty('year', (details or {}).get('year', ''))
                self.setProperty('region', clean_region((details or {}).get('region', '')))
                self.setProperty('plot', (details or {}).get('plot', '') or 'Movie information unavailable.')
                self.setProperty('loading', '')
        except (OSError, ValueError, UnicodeError, sqlite3.Error) as exc:
            xbmc.log('MyStreamPro M4.7 detail: %s' % exc, xbmc.LOGWARNING)
            if not self.dismissed:
                self.setProperty('plot', 'Movie information temporarily unavailable.')
                self.setProperty('loading', '')

    def onClick(self, control_id):
        if control_id == 80:
            self.want_play = True
            self.dismissed = True
            self.close()
        elif control_id == 81:
            self.dismissed = True
            self.close()

    def onAction(self, action):
        if action.getId() in ACTIONS_BACK:
            self.dismissed = True
            self.close()


class XiaobaoMovieDetails(xbmcgui.WindowXMLDialog):
    """Xiaobao movie metadata and playback action."""

    def __init__(self, *args, **kwargs):
        self.movie = kwargs.pop('movie')
        super().__init__(*args, **kwargs)
        self.dismissed = False

    def onInit(self):
        movie = self.movie
        self.setProperty('title', movie.get('title', ''))
        self.setProperty('poster', cached_poster(movie.get('image', '')))
        self.setProperty('year', movie.get('year', ''))
        self.setProperty('quality', movie.get('quality', ''))
        self.setProperty('plot', '正在加载电影资料...')
        self.setProperty('loading', 'Loading details...')
        threading.Thread(target=self._fetch, daemon=True).start()

    def _fetch(self):
        try:
            data = xiaobao.get_movie_details(self.movie['url'])
            if self.dismissed:
                return
            for field in ('title', 'year', 'quality', 'region', 'genre',
                          'cast', 'director'):
                self.setProperty(field, data.get(field, '') or
                                 (self.movie.get(field, '') if field in ('year', 'quality') else ''))
            self.setProperty('rating', data.get('rating') or 'No Rating')
            self.setProperty('plot', data.get('plot', '') or '暂无剧情简介')
            self.setProperty('loading', '')
        except (OSError, ValueError, UnicodeError) as exc:
            xbmc.log('MyStreamPro M4.7 Xiaobao details: %s' % exc, xbmc.LOGWARNING)
            if not self.dismissed:
                self.setProperty('plot', '电影资料暂时无法加载')
                self.setProperty('loading', '')

    def onClick(self, control_id):
        if control_id == 80:
            self.want_play = True
            self.dismissed = True
            self.close()
        elif control_id == 81:
            self.dismissed = True
            self.close()

    def onAction(self, action):
        if action.getId() in ACTIONS_BACK:
            self.dismissed = True
            self.close()


class EpisodePicker(xbmcgui.WindowXMLDialog):
    """Scrollable episode list, touch and D-pad, no playback while modal."""
    def __init__(self, *args, **kwargs):
        self.series = kwargs.pop('series')
        self.episodes = kwargs.pop('episodes')
        self.selected_index = max(0, int(kwargs.pop('selected_index', 0)))
        self.details = kwargs.pop('details', {})
        super().__init__(*args, **kwargs)
        self.play_index = -1

    def onInit(self):
        self.setProperty('navigation_mode', ADDON.getSetting('navigation_mode') or 'remote')
        self.setProperty('series_title', self.series.get('title', ''))
        self.setProperty('episode_count', '%s 集' % len(self.episodes))
        self.setProperty('poster', cached_poster(self.series.get('image', '')) or self.series.get('image', ''))
        self.setProperty('year', str(self.details.get('year', '') or ''))
        self.setProperty('region', clean_region(self.details.get('region', '')))
        rating = self.details.get('rating')
        if not rating:
            rating = self.series.get('rating', '')
        rating = str(rating or '').strip()
        try:
            score = float(rating.removesuffix('/10'))
            rating = ('%g/10' % score if 0 < score <= 10
                      else 'No Rating')
        except (TypeError, ValueError):
            rating = 'No Rating'
        self.setProperty('rating', rating)
        self.setProperty('quality',
                         self.details.get('quality', '') or '')
        self.setProperty('plot', self.details.get('plot', '') or '暂无剧情简介')
        panel = self.getControl(70)
        panel.reset()
        panel.addItems([xbmcgui.ListItem(label=episode['title'])
                        for episode in self.episodes])
        if self.episodes:
            panel.selectItem(min(self.selected_index, len(self.episodes) - 1))
            self.setFocusId(70)

    def onClick(self, control_id):
        if control_id == 70:
            index = self.getControl(70).getSelectedPosition()
            if 0 <= index < len(self.episodes):
                self.play_index = index
                self.close()
        elif control_id == 71:
            self.close()

    def onAction(self, action):
        if action.getId() in ACTIONS_BACK:
            self.close()


class Browser(xbmcgui.WindowXMLDialog):
    """Kodi-native panel: remote navigation and touch scrolling."""

    def __init__(self, *args, **kwargs):
        self.category = kwargs.pop('category', 'movies')
        self.source = kwargs.pop('source', 'olevod')
        self.genre = self.category.split(':', 1)[1] if self.category.startswith('movies:') else None
        self.region = kwargs.pop('initial_region', None) or None
        self.filter_return_index = 0
        self.back_to_parent = False
        self.restore_episode = int(kwargs.pop('restore_episode', -1))
        self.page = max(1, int(kwargs.pop("initial_page", 1)))
        self.initial_index = max(0, int(kwargs.pop("initial_index", 0)))
        super().__init__(*args, **kwargs)
        self.movies = []
        self.items = []
        self.closed = False
        self.play_url = None
        self.generation = 0
        self.poster_lock = threading.Lock()
        self.poster_pending = set()
        self.last_selection = -1
        self.last_nav_index = None
        self.has_next = True  # Unknown until a short/empty catalogue page.
        self.catalogue_error = False

    def _capture_snapshot(self, poster_index, episodes=None, series=None,
                          details=None, episode_index=-1):
        """Preserve both TV navigation levels before closing the browser."""
        snapshot = {
            'source': self.source,
            'kind': ('movies' if self.category.startswith('movies')
                     else 'tv'),
            'category': self.category,
            'region': self.region,
            'page': self.page,
            'index': poster_index,
            'posters': self.movies,
        }
        if episodes is not None:
            snapshot.update({
                'series': series,
                'episodes': episodes,
                'details': details or {},
                'episode_index': episode_index,
            })
        _save_snapshot(snapshot)

    def onInit(self):
        # Remote is the safe default. Tablet users can choose Touch in
        # Add-on information > Configure > Navigation mode.
        mode = ADDON.getSetting('navigation_mode') or 'remote'
        self.setProperty('navigation_mode', mode)
        self.getControl(63).setVisible(True)
        self.setProperty('browser_title', ('小宝影院 电影' if self.category.startswith('movies') else '小宝影院 连续剧') if self.source == 'xiaobaotv' else ('欧乐影院 电影' if self.category.startswith('movies') else '欧乐影院 连续剧'))
        if self.source == 'olevod':
            if self.category.startswith('movies'):
                olevod.load_movie_filters()
            else:
                olevod.load_tv_filters()
        self._update_genre_label()
        self._update_region_label()
        self._load_page()

    def _update_pagination(self):
        self.setProperty('can_previous', 'true' if self.movies and self.page > 1 else 'false')
        self.setProperty('can_next', 'true' if self.movies and self.has_next else 'false')

    def _show_empty(self):
        self.setProperty('empty_message', ('没有找到符合条件的电视剧'
            if not self.category.startswith('movies') else '没有找到符合条件的电影'))
        self.setProperty('empty_visible', 'true')
        self.setFocusId(62)

    def _update_genre_label(self):
        genres = xiaobao.MOVIE_GENRES if self.source == 'xiaobaotv' else olevod.MOVIE_GENRES
        label = (genres[self.genre][1] if self.genre in genres else '全部') if self.category.startswith('movies') else (xiaobao.TV_GENRES.get(self.category, (None, '全部'))[1] if self.source == 'xiaobaotv' else olevod.TV_GENRES.get(self.category, (None, OLEVOD_CATEGORIES.get(self.category, '全部')))[1])
        self.setProperty('genre_label', '分类：' + label + '  ▾')

    def _update_region_label(self):
        prefix = ('类型：' if self.source == 'xiaobaotv' and not self.category.startswith('movies') else '地区：')
        self.setProperty('region_label', prefix + (self.region or '全部') + '  ▾')

    def _select_region(self):
        if self.category.startswith('movies'):
            regions = (xiaobao.MOVIE_REGIONS if self.source == 'xiaobaotv'
                       else olevod.MOVIE_REGIONS)
        else:
            regions = (xiaobao.TV_REGIONS if self.source == 'xiaobaotv'
                       else olevod.TV_REGIONS)
        choices = ['全部'] + list(regions)
        current = self.region or '全部'
        selected = xbmcgui.Dialog().select('选择电影地区' if self.category.startswith('movies') else ('选择连续剧类型' if self.source == 'xiaobaotv' else '选择连续剧地区'), choices,
                                           preselect=choices.index(current) if current in choices else 0)
        if selected < 0:
            return
        region = None if selected == 0 else choices[selected]
        if region == self.region:
            return
        old_region, old_page = self.region, self.page
        self.region = region
        self.has_next = True
        self.page = 1
        self.initial_index = 0
        self.last_selection = -1
        self._update_region_label()
        if not self._load_page():
            self.region = old_region
            self.page = old_page
            self._update_region_label()
            self._update_pagination()

    def _select_genre(self):
        is_movie = self.category.startswith('movies')
        genres = xiaobao.MOVIE_GENRES if self.source == 'xiaobaotv' else olevod.MOVIE_GENRES
        choices = ([('全部', None)] + [(name, key) for key, (_, name) in genres.items()]
                   if is_movie else [(name, key) for key, (_, name) in
                                     (xiaobao.TV_GENRES if self.source == 'xiaobaotv' else olevod.TV_GENRES).items()])
        selected = xbmcgui.Dialog().select('选择电影分类' if is_movie else '选择连续剧分类', [label for label, _ in choices],
                                          preselect=next((i for i, (_, key) in enumerate(choices) if key == (self.genre if is_movie else self.category)), 0))
        if selected < 0:
            return
        new_genre = choices[selected][1]
        if new_genre == (self.genre if is_movie else self.category):
            return
        old_category, old_genre, old_page = self.category, self.genre, self.page
        if is_movie:
            self.genre = new_genre
            self.category = 'movies:' + new_genre if new_genre else 'movies'
        else:
            self.category = new_genre
        self.page = 1
        self.initial_index = 0
        self.last_selection = -1
        self._update_genre_label()
        if not self._load_page():
            self.category, self.genre, self.page = old_category, old_genre, old_page
            self._update_genre_label()
            self._update_pagination()

    def _load_page(self, target_page=None):
        requested_page = self.page if target_page is None else max(1, target_page)
        previous_index = self.getControl(50).getSelectedPosition() if self.movies else 0
        self.generation += 1
        generation = self.generation
        self.setProperty('page_status', 'Loading page %s...' % requested_page)
        snapshot = _read_snapshot() if target_page is None else None
        _m2e3_cache_start = time.monotonic()
        cached = playback_snapshot.matches(
            snapshot, self.source, self.category, requested_page,
            self.region)
        xbmc.log('MSP M2-E3 TIMING snapshot_match hit=%s elapsed_ms=%.1f' %
                 (cached, (time.monotonic() - _m2e3_cache_start) * 1000),
                 xbmc.LOGWARNING)
        if cached:
            next_movies = snapshot['posters']
        else:
            # The progress indicator is only needed for a provider request.
            progress = xbmcgui.DialogProgressBG()
            progress.create('MyStreamPro',
                            'Loading movies, page %s...' % requested_page)
            try:
                next_movies = ((xiaobao.get_movies(self.genre, requested_page, self.region)
                                if self.source == 'xiaobaotv' else olevod.get_movies(self.genre, requested_page, self.region))
                               if self.category.startswith('movies')
                               else (xiaobao.get_dramas(self.category, requested_page, self.region)
                                     if self.source == 'xiaobaotv' else
                                     olevod.get_dramas(self.category, requested_page, self.region)))
            except (OSError, ValueError, UnicodeError) as exc:
                next_movies = None
                self.setProperty('page_status', 'Catalogue error: %s' % exc)
            finally:
                progress.close()
        if next_movies is None:
            # Network/parser errors are not empty catalogues. Keep the old grid
            # and roll back a newly selected filter in the caller.
            self.setProperty('page_status', '无法加载此页')
            xbmcgui.Dialog().notification('MyStreamPro', '无法加载此页')
            self._update_pagination()
            return False
        if not next_movies and target_page is not None:
            # Reaching beyond the final page must not erase the current grid.
            if target_page > self.page:
                self.has_next = False
                self._update_pagination()
                xbmcgui.Dialog().notification('MyStreamPro', '已到最后一页')
            return False
        # An empty first page is a legitimate filter result, not an error.
        self.page = requested_page
        self.last_nav_index = None
        self.movies = next_movies
        # Xiaobao's page size differs from Olevod's 60-card catalogue.
        # Keep Next enabled for a nonempty Xiaobao page; attempting the page
        # after the last one disables Next without clearing the current grid.
        self.has_next = (bool(next_movies) if self.source == 'xiaobaotv'
                         else len(next_movies) >= 60)
        self.setProperty('empty_visible', 'false')
        self.items = []
        for movie in self.movies:
            item = xbmcgui.ListItem(label=movie['title'])
            cached = cached_poster(movie.get('image', ''))
            if cached:
                item.setArt({'thumb': cached, 'poster': cached})
            self.items.append(item)
        panel = self.getControl(50)
        panel.reset()
        panel.addItems(self.items)
        self._update_pagination()
        self.setProperty('page_status', '第 %s 页  |  %s 部' %
                         (requested_page, len(self.movies)))
        if self.movies:
            self.setFocusId(50)
            target = min(self.initial_index, len(self.movies) - 1)
            panel.selectItem(target)
            self.last_nav_index = target
            self.initial_index = 0
            self._selection_changed()
            self._prefetch(0, generation)
            if self.restore_episode >= 0 and not self.category.startswith('movies'):
                episode_index = self.restore_episode
                self.restore_episode = -1
                self._open_episodes(self.movies[target], target, episode_index)
        else:
            self._show_empty()
        return True

    def _prefetch(self, index, generation):
        # Current viewport first, then nearby titles; bounded concurrency.
        start = max(0, (index // 5) * 5 - 5)
        end = min(len(self.movies), start + 12)
        for i in range(start, end):
            url = self.movies[i].get('image', '')
            if not url or cached_poster(url):
                continue
            with self.poster_lock:
                if url in self.poster_pending or len(self.poster_pending) >= 12:
                    continue
                self.poster_pending.add(url)
            threading.Thread(target=self._download, args=(i, url, generation), daemon=True).start()

    def _download(self, index, url, generation):
        try:
            poster = poster_for(url)
            if poster and not self.closed and generation == self.generation:
                # Kodi ListItem artwork is refreshed by the native panel.
                self.items[index].setArt({'thumb': poster, 'poster': poster})
        except (OSError, ValueError, EOFError) as exc:
            xbmc.log('MyStreamPro M4.7 poster: %s' % exc, xbmc.LOGWARNING)
        finally:
            with self.poster_lock:
                self.poster_pending.discard(url)

    def _selection_changed(self):
        if self.closed or not self.movies:
            return
        index = self.getControl(50).getSelectedPosition()
        if not 0 <= index < len(self.movies):
            return
        if index == self.last_selection:
            return
        self.last_selection = index
        movie = self.movies[index]
        self.setProperty('movie_title', movie['title'])
        self.setProperty('movie_rating', '%s/10' % movie['rating'] if movie.get('rating') else '')
        self.setProperty('movie_quality', movie.get('quality', ''))
        self._prefetch(index, self.generation)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in ACTIONS_BACK:
            self.back_to_parent = True
            self.closed = True
            self.close()
            return
        if self.getFocusId() in (62, 63):
            focused = self.getFocusId()
            if action_id == 1 and focused == 63:
                self.setFocusId(62)
            elif action_id == 2 and focused == 62 and True:
                self.setFocusId(63)
            elif action_id == 4:
                if not self.movies:
                    return
                self.setFocusId(50)
                if self.movies:
                    pos = min(self.filter_return_index, len(self.movies) - 1)
                    self.getControl(50).selectItem(pos)
                    self.last_nav_index = pos
            return
        if not self.movies or self.getFocusId() != 50:
            return
        panel = self.getControl(50)
        index = panel.getSelectedPosition()
        if not 0 <= index < len(self.movies):
            return
        previous = self.last_nav_index
        if previous is not None:
            if action_id == 1 and previous % 5 == 0:
                # XML routes Left at the edge to the genre control. Keep a
                # fallback for Kodi skins that deliver a wrapped selection.
                self.genre_entry_index = previous
                if index != previous:
                    panel.selectItem(previous)
                self.setFocusId(62)
                return
            if action_id == 2 and (previous % 5 == 4 or previous == len(self.movies) - 1):
                # Do not wrap at the rightmost poster.
                if index != previous:
                    panel.selectItem(previous)
                self.last_nav_index = previous
                return
        first_row_end = min(5, len(self.movies))
        last_row_start = ((len(self.movies) - 1) // 5) * 5
        if action_id == 4 and self.has_next and previous is not None and previous >= last_row_start:
            if index < first_row_end or index == previous:
                if self._load_page(self.page + 1):
                    self.last_selection = -1
                return
        if action_id == 3 and self.page > 1 and previous is not None and previous < first_row_end:
            if index >= last_row_start or index == previous:
                if not self._load_page(self.page - 1):
                    return
                self.last_selection = -1
                if self.movies:
                    last_row_start = ((len(self.movies) - 1) // 5) * 5
                    self.getControl(50).selectItem(last_row_start + min(previous, len(self.movies) - last_row_start - 1))
                    self.last_nav_index = self.getControl(50).getSelectedPosition()
                    self._selection_changed()
                return
        if action_id in ACTIONS_MOVE:
            self.last_nav_index = index
            self._selection_changed()

    def _open_episodes(self, series, poster_index, episode_index=0):
        try:
            episodes = (xiaobao.get_movie_versions(series['url']) if self.source == 'xiaobaotv'
                        else olevod.get_episodes(series['url']))
            if self.source == 'xiaobaotv':
                episodes = [{'title': item['title'], 'url': item['url']} for item in episodes]
            episodes = newest_first(episodes)
        except (OSError, UnicodeError, ValueError) as exc:
            xbmcgui.Dialog().notification('MyStreamPro', 'Unable to load episodes: %s' % exc,
                                          xbmcgui.NOTIFICATION_ERROR)
            return
        if not episodes:
            xbmcgui.Dialog().notification('MyStreamPro', 'No episodes available')
            return
        details = ({} if self.source == 'xiaobaotv' else cached_detail(series['url']) or {})
        if self.source == 'xiaobaotv':
            try:
                details = xiaobao.get_movie_details(series['url'])
            except (OSError, ValueError, UnicodeError) as exc:
                xbmc.log('MyStreamPro Xiaobao TV details: %s' % exc, xbmc.LOGWARNING)
        elif not details or not details.get('plot') or not details.get('region'):
            try:
                details = get_details(series['url'])
                store_detail(series['url'], details)
            except (OSError, ValueError, UnicodeError, sqlite3.Error) as exc:
                xbmc.log('MyStreamPro M4.7 series detail: %s' % exc, xbmc.LOGWARNING)
        picker = EpisodePicker('Episodes.xml', ADDON.getAddonInfo('path'),
                               'default', '720p', series=series, episodes=episodes,
                               details=details,
                               selected_index=episode_index)
        modal_started = time.monotonic()
        picker.doModal()
        xbmc.log('MSP M2-E8 TIMING tv_modal_elapsed_ms=%.1f' %
                 ((time.monotonic() - modal_started) * 1000),
                 xbmc.LOGWARNING)
        chosen = picker.play_index
        del picker
        if chosen >= 0:
            self._capture_snapshot(
                poster_index, episodes=episodes, series=series,
                details=details, episode_index=chosen)
            self.play_url = episodes[chosen]['url']
            self.series_url = series['url']
            self.episode_index = chosen
            self.play_page = self.page
            self.play_index = poster_index
            self.closed = True
            self.close()

    def onClick(self, control_id):
        if control_id == 63:
            self.filter_return_index = self.getControl(50).getSelectedPosition() if self.movies else 0
            self._select_region()
            return
        if control_id == 62:
            self.filter_return_index = self.getControl(50).getSelectedPosition() if self.movies else 0
            old_category = self.category
            self._select_genre()
            if old_category != self.category:
                self.genre_entry_index = 0
            return
        if control_id in (60, 61):
            if (control_id == 61 and not self.has_next) or not self.movies:
                return
            if control_id == 60 and self.page <= 1:
                return
            if self._load_page(self.page + (-1 if control_id == 60 else 1)):
                self.last_selection = -1
            return
        if control_id != 50 or not self.movies:
            return
        index = self.getControl(50).getSelectedPosition()
        if not 0 <= index < len(self.movies):
            return
        movie = self.movies[index]
        if self.source == 'xiaobaotv' and not self.category.startswith('movies'):
            self._open_episodes(movie, index)
            return
        if self.source == 'xiaobaotv':
            dialog = XiaobaoMovieDetails('XiaobaoDetails.xml',
                                         ADDON.getAddonInfo('path'),
                                         'default', '720p', movie=movie)
            dialog.doModal()
            play = dialog.want_play
            del dialog
            if play:
                self._capture_snapshot(index)
                self.play_url = movie['url']
                self.play_page = self.page
                self.play_index = index
                self.closed = True
                self.close()
            return
        if not self.category.startswith('movies'):
            self._open_episodes(movie, index)
            return
        dialog = MovieDetails('Details.xml', ADDON.getAddonInfo('path'),
                              'default', '720p', movie=movie)
        dialog.doModal()
        play = dialog.want_play
        del dialog
        if play:
            self._capture_snapshot(index)
            self.play_url = movie['url']
            self.play_page = self.page
            self.play_index = index
            self.closed = True
            self.close()


def resume_position(version_key):
    """Read the same private database maintained by the background service."""
    try:
        with cache_connection() as connection:
            connection.execute('CREATE TABLE IF NOT EXISTS playback '
                               '(movie_url TEXT PRIMARY KEY, position REAL, duration REAL, updated INTEGER)')
            row = connection.execute('SELECT position, duration FROM playback WHERE movie_url=?',
                                     (version_key,)).fetchone()
        if not row:
            xbmc.log('MyStreamPro M4.7 DIAG: bookmark lookup MISS', xbmc.LOGWARNING)
            return 0
        position, duration = float(row[0] or 0), float(row[1] or 0)
        if position < 30 or (duration > 0 and position >= duration - 90):
            return 0
        xbmc.log('MyStreamPro M4.7 DIAG: bookmark lookup position=%.1f duration=%.1f' % (position, duration), xbmc.LOGWARNING)
        return position
    except (sqlite3.Error, ValueError, TypeError) as exc:
        xbmc.log('MyStreamPro M4.7 bookmark lookup: %s' % exc, xbmc.LOGWARNING)
        return 0


def clear_resume(version_key):
    try:
        with cache_connection() as connection:
            connection.execute('DELETE FROM playback WHERE movie_url=?', (version_key,))
    except sqlite3.Error:
        pass


def format_position(seconds):
    seconds = int(seconds)
    return '%d:%02d:%02d' % (seconds // 3600, (seconds // 60) % 60, seconds % 60)


def request_browser_return(page, index, reason, category="movies", episode=-1, region=None):
    # Cancel happens before playback, so the player stop callback will not fire.
    signal = {'page': page, 'index': index, 'reason': reason,
              'category': category, 'episode': episode, 'region': region,
              'source': 'xiaobaotv' if reason.startswith('xiaobao_') else 'olevod',
              'created': time.time()}
    xbmcgui.Window(10000).setProperty('MyStreamProV1.ReturnRequest', json.dumps(signal))
    xbmc.log('MyStreamPro M4.7 DIAG: return requested reason=%s page=%s index=%s' %
             (reason, page, index), xbmc.LOGWARNING)


def home():
    for label, source, kind in (
        ('欧乐影院 电影', 'olevod', 'movies'),
        ('欧乐影院 连续剧', 'olevod', 'tv'),
        ('小宝影院 电影', 'xiaobaotv', 'movies'),
        ('小宝影院 连续剧', 'xiaobaotv', 'tv'),
        # ('中文直播电视 (Live TV)', 'livetv', 'live'),
    ):
        item = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(HANDLE, 'plugin://' + ADDON.getAddonInfo('id') + '/?' +
                                    urlencode({'source': source, 'kind': kind}), item, True)
    xbmcplugin.endOfDirectory(HANDLE)


def tv_categories():
    for key, label in OLEVOD_CATEGORIES.items():
        item = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(HANDLE, 'plugin://' + ADDON.getAddonInfo('id') + '/?' +
                                    urlencode({'source': 'olevod', 'kind': 'tv',
                                               'category': key}), item, True)
    xbmcplugin.endOfDirectory(HANDLE)


def navigate_to(args):
    """Navigate only after modal closes; never hold a modal through playback."""
    uri = 'plugin://' + ADDON.getAddonInfo('id') + '/'
    if args:
        uri += '?' + urlencode(args)
    xbmc.log('MyStreamPro M4.7 DIAG: navigate %s' % uri, xbmc.LOGWARNING)
    # A restored poster grid has no Kodi directory ancestry. When returning
    # to TV categories, seed the real MyStreamPro home directory first, then
    # push the original Kodi category directory onto its navigation history.
    if args.get('source') == 'olevod' and args.get('kind') == 'tv' and not args.get('category'):
        xbmcgui.Window(10000).setProperty('MyStreamProV1.CategoryNavRequest',
            json.dumps({'created': time.time()}))
    else:
        xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % uri)


def return_to_tv_posters(source, category, page, index, region=None):
    """Defer TV poster restoration until the episode plugin call exits.

    Kodi cannot reliably replace the video directory while the restored
    episode picker is still executing inside its plugin directory request.
    """
    xbmcgui.Window(10000).setProperty(
        'MyStreamProV1.TvPosterNavRequest',
        json.dumps({
            'created': time.time(),
            'source': source,
            'category': category,
            'page': page,
            'index': index,
            'region': region or '',
        }))


def restore_episode_direct(category, page, index, episode_index, region=None):
    """Open episode list first; defer the parent poster grid until Back."""
    try:
        snapshot = _read_snapshot()
        state = playback_snapshot.tv_state(
            snapshot, 'olevod', category, page, index, region)
        if state is not None:
            series, episodes, details = state
        else:
            series_list = olevod.get_dramas(category, page, region)
            if not series_list or index >= len(series_list):
                raise ValueError('Series not available on saved page')
            series = series_list[index]
            episodes = newest_first(olevod.get_episodes(series['url']))
        if not episodes:
            raise ValueError('No episodes available')
        if state is None:
            details = cached_detail(series['url']) or {}
            if not details or not details.get('plot') or not details.get('region'):
                try:
                    details = get_details(series['url'])
                    store_detail(series['url'], details)
                except (OSError, ValueError, UnicodeError, sqlite3.Error) as exc:
                    xbmc.log('MyStreamPro M4.7 detail: %s' % exc, xbmc.LOGWARNING)
        picker = EpisodePicker('Episodes.xml', ADDON.getAddonInfo('path'),
                               'default', '720p', series=series, episodes=episodes,
                               details=details, selected_index=episode_index)
        modal_started = time.monotonic()
        picker.doModal()
        xbmc.log('MSP M2-E8 TIMING tv_modal_elapsed_ms=%.1f' %
                 ((time.monotonic() - modal_started) * 1000),
                 xbmc.LOGWARNING)
        chosen = picker.play_index
        del picker
        if chosen >= 0 and state is not None:
            snapshot['episode_index'] = chosen
            _save_snapshot(snapshot)
        if chosen < 0:
            return_to_tv_posters('olevod', category, page, index, region)
            return
        # Do not open a poster grid just to start an episode.
        play_selection(episodes[chosen]['url'], page, index, category, chosen, region)
    except (OSError, ValueError, UnicodeError) as exc:
        xbmcgui.Dialog().notification('MyStreamPro', str(exc), xbmcgui.NOTIFICATION_ERROR)
        return_to_tv_posters('olevod', category, page, index, region)


def restore_xiaobao_episode_direct(category, page, index, episode_index, region=None):
    """Restore Xiaobao TV episode picker without flashing the poster browser."""
    try:
        snapshot = _read_snapshot()
        state = playback_snapshot.tv_state(
            snapshot, 'xiaobaotv', category, page, index, region)
        if state is not None:
            series, episodes, details = state
        else:
            series_list = xiaobao.get_dramas(category, page, region)
            if not series_list or index >= len(series_list):
                raise ValueError('Series not available on saved page')
            series = series_list[index]
            episodes = newest_first(xiaobao.get_movie_versions(series['url']))
        if not episodes:
            raise ValueError('No episodes available')
        if state is None:
            try:
                details = xiaobao.get_movie_details(series['url'])
            except (OSError, ValueError, UnicodeError) as exc:
                xbmc.log('MyStreamPro Xiaobao TV details: %s' % exc, xbmc.LOGWARNING)
                details = {}
        picker = EpisodePicker('Episodes.xml', ADDON.getAddonInfo('path'),
                               'default', '720p', series=series, episodes=episodes,
                               details=details, selected_index=episode_index)
        picker.doModal()
        chosen = picker.play_index
        del picker
        if chosen >= 0 and state is not None:
            snapshot['episode_index'] = chosen
            _save_snapshot(snapshot)
        if chosen < 0:
            return_to_tv_posters('xiaobaotv', category, page, index, region)
            return
        play_xiaobao_selection(episodes[chosen]['url'], page, index, category,
                               region, chosen)
    except (OSError, ValueError, UnicodeError) as exc:
        xbmcgui.Dialog().notification('MyStreamPro', str(exc), xbmcgui.NOTIFICATION_ERROR)
        return_to_tv_posters('xiaobaotv', category, page, index, region)


def play_selection(selected, selected_page, selected_index, browser_category, episode_index, region=None):
    """Shared TV episode playback, used by direct restore and poster browser."""
    try:
        version_key = 'episode::' + selected
        position = resume_position(version_key)
        if position:
            choice = xbmcgui.Dialog().select('Continue watching?',
                ['Resume at %s' % format_position(position), 'Start Over'])
            if choice < 0:
                request_browser_return(selected_page, selected_index,
                    'resume_cancel', browser_category, episode_index, region=region)
                return
            if choice == 1:
                clear_resume(version_key)
                position = 0
        stream = olevod.get_stream_url(selected)
        if not stream:
            raise ValueError('No playable stream found')
        signal = {'movie_url':version_key,'resume':position,'page':selected_page,
                  'index':selected_index,'category':browser_category,
                  'episode':episode_index,'region':region,'created':time.time()}
        xbmcgui.Window(10000).setProperty('MyStreamProV1.PlayRequest', json.dumps(signal))
        item = xbmcgui.ListItem(path=stream)
        item.setProperty('IsPlayable', 'true')
        xbmc.Player().play(stream, item)
    except (OSError, ValueError, UnicodeError) as exc:
        xbmcgui.Dialog().notification('MyStreamPro', str(exc), xbmcgui.NOTIFICATION_ERROR)
        request_browser_return(selected_page, selected_index,
            'stream_error', browser_category, episode_index, region=region)


def play_xiaobao_selection(selected, page, index, category, region=None, episode_index=-1):
    """Play an iBaoTV movie version or selected TV episode."""
    try:
        if episode_index >= 0:
            versions = [{'title': 'Episode', 'url': selected}]
        else:
            versions = xiaobao.get_movie_versions(
                selected, episodes_only=False
            )

        if not versions:
            raise ValueError('没有可用的播放线路')

        chosen = 0
        if len(versions) > 1:
            chosen = xbmcgui.Dialog().select(
                '选择播放版本',
                [version['title'] for version in versions],
            )

        if chosen < 0:
            request_browser_return(
                page, index, 'xiaobao_language_cancel',
                category, episode_index, region=region
            )
            return

        version = versions[chosen]
        version_key = 'xiaobao::' + version['url']
        position = resume_position(version_key)
        if position:
            choice = xbmcgui.Dialog().select('Continue watching?',
                ['Resume at %s' % format_position(position), 'Start Over'])
            if choice < 0:
                request_browser_return(page, index, 'xiaobao_resume_cancel', category, episode_index, region=region)
                return
            if choice == 1:
                clear_resume(version_key)
                position = 0
        stream = xiaobao.get_stream_url(version['url'])
        signal = {'movie_url': version_key, 'resume': position,
                  'page': page, 'index': index, 'category': category,
                  'source': 'xiaobaotv', 'episode': episode_index, 'region': region,
                  'created': time.time()}
        xbmcgui.Window(10000).setProperty('MyStreamProV1.PlayRequest', json.dumps(signal))
        item = xbmcgui.ListItem(path=stream)
        item.setProperty('IsPlayable', 'true')
        xbmc.Player().play(stream, item)
    except (OSError, ValueError, UnicodeError) as exc:
        xbmcgui.Dialog().notification('MyStreamPro', str(exc), xbmcgui.NOTIFICATION_ERROR)
        request_browser_return(page, index, 'xiaobao_stream_error', category, episode_index, region=region)


def main():
    # M2-E9: prevent a second MSP browser while Kodi plays video.
    # Keep Kodi's Back button unchanged and preserve the restore snapshot.
    if xbmc.Player().isPlayingVideo():
        xbmc.log('MSP M2-E9 GUARD: launch during active video',
                 xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            'MyStreamPro', 'Stop the video before browsing.',
            xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    _m2e3_started = time.monotonic()
    xbmc.log('MSP M2-E3 TIMING plugin_enter', xbmc.LOGWARNING)
    args = parse_qs(sys.argv[2].lstrip('?') if len(sys.argv) > 2 else '')
    source = args.get('source', [''])[0]
    kind = args.get('kind', [''])[0]
    category = args.get('category', [''])[0]
    xbmc.log('MSP M2-E3 TIMING route source=%s kind=%s category=%s' %
             (source, kind, category), xbmc.LOGWARNING)
    if not source:
        home()
        return
    if source == 'livetv':
        live_tv.open_grid(ADDON, args)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if source == 'xiaobaotv':
        if kind not in ('movies', 'tv'):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        try:
            page = max(1, int(args.get('page', ['1'])[0]))
            index = max(0, int(args.get('index', ['0'])[0]))
        except (ValueError, TypeError):
            page, index = 1, 0
        genre = args.get('category', [''])[0]
        if kind == 'movies':
            category = 'movies:' + genre if genre in xiaobao.MOVIE_GENRES else 'movies'
        else:
            category = genre if genre in xiaobao.TV_GENRES else 'tv_all'
        restore_episode = int(args.get('episode', ['-1'])[0])
        if kind == 'tv' and restore_episode >= 0:
            restore_xiaobao_episode_direct(category, page, index, restore_episode,
                                           args.get('region', [''])[0] or None)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        browser = Browser('Browser.xml', ADDON.getAddonInfo('path'),
                          'default', '720p', source='xiaobaotv', category=category,
                          initial_page=page, initial_index=index,
                          restore_episode=int(args.get('episode', ['-1'])[0]),
                          initial_region=args.get('region', [''])[0])
        browser.doModal()
        back_to_parent = browser.back_to_parent
        selected = browser.play_url
        page, index, category = browser.page, (getattr(browser, 'play_index', index)
                                                if selected else index), browser.category
        region = browser.region
        episode_index = getattr(browser, 'episode_index', -1)
        browser.closed = True
        del browser
        if selected:
            play_xiaobao_selection(selected, page, index, category, region,
                                   episode_index)
        elif back_to_parent:
            _discard_snapshot()
            navigate_to({})
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if source != 'olevod':
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if kind == 'tv' and not category:
        category = 'latest'
    if kind == 'tv':
        olevod.load_tv_filters()
    if kind == 'tv' and category not in olevod.TV_GENRES:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if kind == 'movies':
        olevod.load_movie_filters()
    browser_category = category if kind == 'tv' else ('movies:' + category if category in olevod.MOVIE_GENRES else 'movies')
    try:
        initial_page = max(1, int(args.get('page', ['1'])[0]))
        initial_index = max(0, int(args.get('index', ['0'])[0]))
        restore_episode = int(args.get('episode', ['-1'])[0])
    except (ValueError, TypeError):
        initial_page, initial_index, restore_episode = 1, 0, -1
    if kind == 'tv' and restore_episode >= 0:
        restore_episode_direct(browser_category, initial_page, initial_index, restore_episode, args.get('region', [''])[0] or None)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    window = Browser('Browser.xml', ADDON.getAddonInfo('path'), 'default', '720p',
                     category=browser_category, initial_page=initial_page,
                     initial_index=initial_index, restore_episode=restore_episode,
                     initial_region=args.get('region', [''])[0])
    window.doModal()
    back_to_parent = window.back_to_parent
    selected = window.play_url
    # Capture the live browser genre before destroying the modal.
    # The entry route may still say 'movies' even after the user changes genre.
    browser_category = window.category
    selected_region = window.region
    selected_page = getattr(window, 'play_page', initial_page)
    selected_index = getattr(window, 'play_index', initial_index)
    episode_index = getattr(window, 'episode_index', -1)
    window.closed = True
    del window
    if back_to_parent and not selected:
        _discard_snapshot()
        if kind == 'tv':
            navigate_to({})
        else:
            navigate_to({})
    if selected:
        if kind == 'tv':
            play_selection(selected, selected_page, selected_index, browser_category, episode_index, selected_region)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        try:
            if kind == 'tv':
                # M2's official episode parser returns the stable sid/1 episode URL.
                # Never key progress on an expiring HLS stream URL.
                version_key = 'episode::' + selected
                position = resume_position(version_key)
                if position:
                    choice = xbmcgui.Dialog().select('Continue watching?',
                        ['Resume at %s' % format_position(position), 'Start Over'])
                    if choice < 0:
                        request_browser_return(selected_page, selected_index,
                            'resume_cancel', browser_category, episode_index, region=region)
                        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                        return
                    if choice == 1:
                        clear_resume(version_key)
                        position = 0
                stream = olevod.get_stream_url(selected)
            else:
                versions = olevod.get_movie_versions(selected)
                if not versions:
                    raise ValueError('No player found')
                index = 0
                if len(versions) > 1:
                    index = xbmcgui.Dialog().select('Choose Movie Language',
                        [version['title'] for version in versions])
                if index < 0:
                    request_browser_return(selected_page, selected_index,
                        'language_cancel', browser_category, region=selected_region)
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                    return
                version = versions[index]
                version_key = selected + '::' + version['url']
                position = resume_position(version_key)
                if position:
                    choice = xbmcgui.Dialog().select('Continue watching?',
                        ['Resume at %s' % format_position(position), 'Start Over'])
                    if choice < 0:
                        request_browser_return(selected_page, selected_index,
                            'resume_cancel', browser_category, region=selected_region)
                        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                        return
                    if choice == 1:
                        clear_resume(version_key)
                        position = 0
                stream = olevod.get_stream_url(version['url'])
            if not stream:
                raise ValueError('No playable stream found')
            signal = {'movie_url': version_key, 'resume': position,
                      'page': selected_page, 'index': selected_index,
                      'category': browser_category, 'episode': episode_index,
                      'region': selected_region, 'source': 'olevod',
                      'created': time.time()}
            xbmcgui.Window(10000).setProperty('MyStreamProV1.PlayRequest', json.dumps(signal))
            item = xbmcgui.ListItem(path=stream)
            item.setProperty('IsPlayable', 'true')
            xbmc.Player().play(stream, item)
        except (OSError, ValueError, UnicodeError) as exc:
            xbmcgui.Dialog().notification('MyStreamPro', str(exc), xbmcgui.NOTIFICATION_ERROR)
            request_browser_return(selected_page, selected_index,
                'stream_error', browser_category, episode_index, region=selected_region)
    xbmc.log('MSP M2-E3 TIMING plugin_exit elapsed_ms=%.1f' %
             ((time.monotonic() - _m2e3_started) * 1000), xbmc.LOGWARNING)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


if __name__ == '__main__':
    main()
