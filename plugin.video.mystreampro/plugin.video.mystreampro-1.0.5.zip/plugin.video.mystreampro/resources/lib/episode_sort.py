"""Provider-independent, stable episode ordering for TV playlists."""

import re


_EPISODE_PATTERNS = (
    re.compile(r"第\s*(\d+)\s*[集話话期]"),
    re.compile(r"(?:episode|ep\.?|e)\s*[-:# ]*\s*(\d+)\b", re.I),
    re.compile(r"^\s*(\d+)\s*(?:集|話|话)?\s*$"),
)


def episode_number(title):
    """Extract a recognized episode number, or return None."""
    for pattern in _EPISODE_PATTERNS:
        match = pattern.search(str(title))
        if match:
            return int(match.group(1))
    return None


def newest_first(episodes):
    """Sort recognized episode numbers descending, preserving all other items.

    Unrecognized titles stay at their original positions, so special episodes,
    source labels, and playlists without numbers are not scrambled.
    """
    ordered = list(episodes)
    positions = []
    numbered = []
    for index, episode in enumerate(ordered):
        number = episode_number(episode.get('title', ''))
        if number is not None:
            positions.append(index)
            numbered.append((number, episode))
    numbered.sort(key=lambda pair: pair[0], reverse=True)
    for index, (_, episode) in zip(positions, numbered):
        ordered[index] = episode
    return ordered
