"""Temporary playback navigation snapshots stored outside Kodi modal windows."""

import json
import os
import sqlite3


SESSION_ID = 'active'


def _connect(profile_path):
    """Open the add-on's private playback snapshot database."""
    os.makedirs(profile_path, exist_ok=True)
    path = os.path.join(profile_path, 'playback_snapshot.sqlite3')
    connection = sqlite3.connect(path, timeout=5)
    connection.execute(
        'CREATE TABLE IF NOT EXISTS snapshots '
        '(session_id TEXT PRIMARY KEY, payload TEXT NOT NULL)'
    )
    return connection


def save(profile_path, session_id, snapshot):
    """Persist a JSON-compatible navigation snapshot."""
    payload = json.dumps(snapshot, ensure_ascii=False)
    with _connect(profile_path) as connection:
        connection.execute(
            'INSERT OR REPLACE INTO snapshots '
            '(session_id, payload) VALUES (?, ?)',
            (session_id, payload),
        )


def load(profile_path, session_id):
    """Return the saved snapshot, or None if none exists."""
    with _connect(profile_path) as connection:
        row = connection.execute(
            'SELECT payload FROM snapshots WHERE session_id = ?',
            (session_id,),
        ).fetchone()
    return json.loads(row[0]) if row else None


def delete(profile_path, session_id):
    """Discard a snapshot after its navigation session is complete."""
    with _connect(profile_path) as connection:
        connection.execute(
            'DELETE FROM snapshots WHERE session_id = ?',
            (session_id,),
        )


def matches(snapshot, source, category, page, region):
    """Check whether cached poster data belongs to the requested grid."""
    return bool(
        isinstance(snapshot, dict)
        and snapshot.get('source') == source
        and snapshot.get('category') == category
        and snapshot.get('page') == page
        and (snapshot.get('region') or None) == (region or None)
        and isinstance(snapshot.get('posters'), list)
    )


def tv_state(snapshot, source, category, page, index, region):
    """Return validated TV data for a restored episode picker."""
    if not matches(snapshot, source, category, page, region):
        return None
    if snapshot.get('kind') != 'tv' or snapshot.get('index') != index:
        return None
    posters = snapshot['posters']
    if not 0 <= index < len(posters):
        return None
    series = snapshot.get('series')
    episodes = snapshot.get('episodes')
    if not isinstance(series, dict) or not isinstance(episodes, list):
        return None
    if not episodes or series.get('url') != posters[index].get('url'):
        return None
    if not all(isinstance(item, dict) and item.get('url')
               for item in episodes):
        return None
    return series, episodes, snapshot.get('details') or {}
