"""Five-channel Live TV browser with Kodi service-managed playback return."""
import json
import time
from urllib.parse import urlencode
import xbmc
import xbmcgui
import os

# First stream is preferred; additional streams are backups.
CHANNELS = [
    {'name': 'TVB 翡翠台', 'logo': 'tvb-jade-hk.png', 'urls': ['http://r.jdshipin.com/GeWKr', 'http://r.jdshipin.com/qrfbg']},
    {'name': 'TVB Plus', 'logo': 'tvb-plus-hk.png', 'local_logo': 'tvb-plus.png', 'urls': ['http://r.jdshipin.com/Nr5jq', 'http://r.jdshipin.com/ndGgS']},
    {'name': 'TVB 明珠台', 'logo': 'tvb-pearl-hk.png', 'urls': ['http://r.jdshipin.com/ZQ4kN', 'http://r.jdshipin.com/jUx8K']},
    {'name': 'TVB 無綫新聞台', 'logo': 'tvb-news-channel-hk.png', 'urls': ['http://r.jdshipin.com/CkuBd']},
    {'name': 'TVB 星河頻道', 'logo': 'tvb-xing-he-hk.png', 'urls': ['http://r.jdshipin.com/Voac4']},
    {'name': 'ViuTV 99', 'logo': 'viutv-hk.png', 'local_logo': 'viutv-99.png', 'urls': ['http://120.234.44.98:18180/TV00000000000000000037@HHZT']},
]
LOGO_BASE = 'https://tvlogo.org/hong-kong/'
BACK = {9, 10, 92}


class LiveGrid(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.initial_index = int(kwargs.pop('initial_index', 0))
        self.addon_path = kwargs.pop('addon_path', '')
        super().__init__(*args, **kwargs)
        self.selected = -1
        self.back_to_home = False

    def onInit(self):
        panel = self.getControl(50)
        items = []
        addon_path = self.addon_path
        for channel in CHANNELS:
            item = xbmcgui.ListItem(label=channel['name'])
            logo = (os.path.join(addon_path, 'resources', 'media',
                                     'livetv', channel['local_logo'])
                    if channel.get('local_logo') else
                    LOGO_BASE + channel['logo'])
            item.setArt({'thumb': logo, 'poster': logo})
            items.append(item)
        panel.addItems(items)
        panel.selectItem(min(max(self.initial_index, 0), len(items) - 1))
        self.setFocusId(50)

    def onClick(self, control_id):
        if control_id == 50:
            self.selected = self.getControl(50).getSelectedPosition()
            self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.back_to_home = True
            self.close()


def open_grid(addon, args):
    try:
        index = max(0, int(args.get('index', ['0'])[0]))
    except (TypeError, ValueError):
        index = 0
    dialog = LiveGrid('LiveTV.xml', addon.getAddonInfo('path'), 'default', '720p',
                      initial_index=index, addon_path=addon.getAddonInfo('path'))
    dialog.doModal()
    chosen = dialog.selected
    back = dialog.back_to_home
    del dialog
    if back:
        xbmc.executebuiltin('ActivateWindow(Videos,"plugin://%s/",return)' % addon.getAddonInfo('id'))
        return
    if not 0 <= chosen < len(CHANNELS):
        return
    channel = CHANNELS[chosen]
    signal = {'movie_url': 'livetv::' + channel['name'], 'source': 'livetv',
              'category': 'live', 'page': 1, 'index': chosen, 'episode': -1,
              'live_urls': channel['urls'], 'resume': 0, 'created': time.time()}
    xbmcgui.Window(10000).setProperty('MyStreamProV1.PlayRequest', json.dumps(signal))
    item = xbmcgui.ListItem(path=channel['urls'][0])
    item.setProperty('IsPlayable', 'true')
    xbmc.Player().play(channel['urls'][0], item)
