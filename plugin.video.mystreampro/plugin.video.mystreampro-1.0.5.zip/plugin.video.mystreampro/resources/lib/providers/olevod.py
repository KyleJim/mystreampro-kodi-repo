
"""Olevod provider for MyStreamPro."""
import json
import re
import time
from html.parser import HTMLParser
from urllib.parse import quote, urljoin
from urllib.request import Request, urlopen


BASE_URL = "https://www.olehdtv.com"
CATEGORY_IDS = {
    "latest": 2,  # Olevod TV-series type; verify on device
    "china": 202,
    "western": 201,
    "hk_taiwan": 203,
    "japan_korea": 204,
    "short": 1207,
}


class DramaListParser(HTMLParser):
    """Extract drama listings from an Olevod catalogue page."""

    def __init__(self):
        super().__init__()
        self.dramas = []

    def handle_starttag(self, tag, attrs):
        """Process HTML opening tags."""
        if tag != "a":
            return

        attributes = dict(attrs)
        classes = attributes.get("class", "").split()

        if "vodlist_thumb" not in classes:
            return

        title = attributes.get("title", "")
        href = attributes.get("href", "")
        image = attributes.get("data-original", "")

        if not title or not href:
            return

        if "/vod/detail/" not in href:
            return

        self.dramas.append({
            "title": title,
            "url": urljoin(BASE_URL, href),
            "image": urljoin(BASE_URL, image) if image else "",
        })


def get_dramas(category, page=1, region=None):
    """Fetch TV series using the website's category and optional region."""
    if page < 1:
        raise ValueError("Invalid page number")
    if category not in TV_GENRES:
        raise ValueError("Unsupported drama category")
    category_id = TV_GENRES[category][0]
    area_path = f"area/{quote(region, safe='')}/" if region else ""
    url = (f"{BASE_URL}/index.php/vod/show/"
           f"{area_path}id/{category_id}/page/{page}.html")
    parser = MovieListParser()
    parser.feed(fetch_html(url))
    return parser.movies


class EpisodeListParser(HTMLParser):
    """Extract official-player episodes from a drama page."""

    def __init__(self):
        super().__init__()
        self.episodes = []
        self._seen_urls = set()
        self._current_url = None
        self._current_title = []

    def handle_starttag(self, tag, attrs):
        """Find episode links."""
        if tag != "a":
            return

        href = dict(attrs).get("href", "")
        pattern = r"/vod/play/id/\d+/sid/1/nid/\d+\.html"

        if not re.search(pattern, href):
            return

        self._current_url = urljoin(BASE_URL, href)
        self._current_title = []

    def handle_data(self, data):
        """Collect the episode title."""
        if self._current_url:
            self._current_title.append(data)

    def handle_endtag(self, tag):
        """Save a completed episode link."""
        if tag != "a" or not self._current_url:
            return

        title = "".join(self._current_title).strip()
        url = self._current_url

        if re.fullmatch(r"第\d+集", title):
            if url not in self._seen_urls:
                self.episodes.append({
                    "title": title,
                    "url": url,
                })
                self._seen_urls.add(url)

        self._current_url = None
        self._current_title = []


def fetch_html(url, timeout=15):
    """Download HTML from an Olevod page."""
    if not url.startswith(f"{BASE_URL}/index.php/vod/"):
        raise ValueError("Unsupported Olevod URL")

    request = Request(
        url,
        headers={"User-Agent": "Mozilla/5.0"},
    )

    with urlopen(request, timeout=timeout) as response:
        return response.read().decode(
            "utf-8",
            errors="replace",
        )


def get_episodes(drama_url):
    """Return episodes from an Olevod drama detail page."""
    html = fetch_html(drama_url)

    parser = EpisodeListParser()
    parser.feed(html)

    return parser.episodes


def get_stream_url(episode_url):
    """Extract the selected player's HLS stream URL."""
    html = fetch_html(episode_url)

    match = re.search(
        r"var\s+player_aaaa\s*=\s*(\{[^;]+\})",
        html,
    )

    if not match:
        raise ValueError("Player configuration not found")

    player = json.loads(match.group(1))

    if player.get("encrypt") != 0:
        raise ValueError("Encrypted player URLs are unsupported")

    stream_url = player.get("url", "")

    if not stream_url.startswith("https://"):
        raise ValueError("Unsupported stream URL")

    return stream_url


MOVIE_GENRES = {
    "action": (101, "动作片"),
    "comedy": (102, "喜剧片"),
    "romance": (103, "爱情片"),
    "sci_fi": (104, "科幻片"),
    "horror": (105, "恐怖片"),
    "drama": (106, "剧情片"),
    "war": (107, "战争片"),
    "animation": (108, "动画片"),
    "mystery": (109, "悬疑片"),
    "thriller": (110, "惊悚片"),
    "documentary": (111, "纪录片"),
    "fantasy": (112, "奇幻片"),
    "crime": (113, "犯罪片"),
}


# TV options are independently loaded from the TV catalogue, never movies.
TV_GENRES = {key: (value, {"latest": "全部", "china": "国产剧",
    "western": "欧美剧", "hk_taiwan": "港台剧", "japan_korea": "日韩剧",
    "short": "短剧"}[key]) for key, value in CATEGORY_IDS.items()}
TV_REGIONS = ("大陆", "香港", "台湾", "美国", "韩国", "日本", "印度",
              "英国", "法国", "加拿大", "西班牙", "俄罗斯", "意大利",
              "泰国", "新加坡", "马来西亚", "其它")
_TV_FILTERS_LOADED_AT = 0


def load_tv_filters():
    """Cache Olevod TV genre/region options read from its TV filter menu."""
    global _TV_FILTERS_LOADED_AT, TV_REGIONS
    if time.monotonic() - _TV_FILTERS_LOADED_AT < 3600:
        return
    from .movie_filters import parse_filters
    try:
        genres, regions = parse_filters(
            fetch_html(BASE_URL + "/index.php/vod/show/id/2.html"), "olevod")
        if not genres or not regions:
            raise ValueError("TV filter menu missing")
        old_genres = dict(TV_GENRES)
        TV_GENRES.clear()
        TV_GENRES["latest"] = (2, "全部")
        for genre_id, label in genres:
            key = next((key for key, (id_value, _) in old_genres.items()
                        if id_value == int(genre_id)), "tv_web_" + genre_id)
            TV_GENRES[key] = (int(genre_id), label)
        TV_REGIONS = tuple(regions)
        _TV_FILTERS_LOADED_AT = time.monotonic()
    except Exception:
        _TV_FILTERS_LOADED_AT = time.monotonic() - 3600 + 120


class MovieListParser(HTMLParser):
    """Read movie thumbnails and their nested quality/rating labels."""

    def __init__(self):
        super().__init__()
        self.movies = []
        self._movie = None
        self._field = None
        self._quality_depth = 0

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        classes = attributes.get("class", "").split()
        if tag == "a" and "vodlist_thumb" in classes:
            href = attributes.get("href", "")
            title = attributes.get("title", "")
            if "/vod/detail/" not in href or not title:
                return
            image = attributes.get("data-original", "")
            self._movie = {
                "title": title,
                "url": urljoin(BASE_URL, href),
                "image": urljoin(BASE_URL, image) if image else "",
                "quality": "",
                "rating": "",
            }
            self._field = None
            self._quality_depth = 0
        elif self._movie is not None:
            if tag == "span" and "vodlist_top" in classes:
                self._quality_depth += 1
            elif tag == "em" and self._quality_depth:
                self._field = "quality"
            elif tag == "span" and "text_right" in classes:
                self._field = "rating"

    def handle_data(self, data):
        if self._movie is None or self._field is None:
            return
        value = data.strip()
        if self._field == "quality" and value in ("高清", "超清"):
            self._movie["quality"] = value
        elif self._field == "rating":
            if re.fullmatch(r"\d+(?:\.\d+)?", value):
                self._movie["rating"] = value

    def handle_endtag(self, tag):
        if self._movie is None:
            return
        if tag == "em" or tag == "span":
            self._field = None
            if tag == "span" and self._quality_depth:
                self._quality_depth -= 1
        elif tag == "a":
            self.movies.append(self._movie)
            self._movie = None
            self._field = None
            self._quality_depth = 0


MOVIE_REGIONS = ("大陆", "香港", "台湾", "美国", "日本", "韩国", "英国", "法国")

_FILTERS_LOADED_AT = 0
_FILTERS_CACHE_SECONDS = 3600

def load_movie_filters():
    """Refresh both movie filters from the provider catalogue, with fallback."""
    global _FILTERS_LOADED_AT, MOVIE_REGIONS
    if time.monotonic() - _FILTERS_LOADED_AT < _FILTERS_CACHE_SECONDS:
        return
    from .movie_filters import parse_filters
    try:
        markup = fetch_html(BASE_URL + "/index.php/vod/show/id/1.html")
        genres, regions = parse_filters(markup, "olevod")
        if not genres or not regions:
            raise ValueError("Movie filter menu missing")
        old_genres = dict(MOVIE_GENRES)
        MOVIE_GENRES.clear()
        for genre_id, label in genres:
            key = next((key for key, (id_value, _) in old_genres.items()
                        if id_value == int(genre_id)), "web_" + genre_id)
            MOVIE_GENRES[key] = (int(genre_id), label)
        MOVIE_REGIONS = tuple(regions)
        _FILTERS_LOADED_AT = time.monotonic()
    except Exception:
        # Keep the last successful options (or original built-in fallback).
        _FILTERS_LOADED_AT = time.monotonic() - _FILTERS_CACHE_SECONDS + 120



def get_movies(genre=None, page=1, region=None):
    """Fetch an Olevod movie catalogue page."""
    if page < 1:
        raise ValueError("Invalid page number")
    if genre is not None and genre not in MOVIE_GENRES:
        raise ValueError("Unsupported movie genre")
    genre_id = MOVIE_GENRES[genre][0] if genre else 1
    area_path = f"area/{quote(region, safe='')}/" if region else ""
    url = (
        f"{BASE_URL}/index.php/vod/show/"
        f"{area_path}id/{genre_id}/page/{page}.html"
    )
    parser = MovieListParser()
    parser.feed(fetch_html(url))
    return parser.movies


class MovieVersionParser(HTMLParser):
    """Extract only regular movie playback links, never VIP links."""

    def __init__(self):
        super().__init__()
        self.versions = []
        self._url = None
        self._label = []
        self._seen = set()

    def handle_starttag(self, tag, attrs):
        if tag != "a":
            return
        href = dict(attrs).get("href", "")
        if not re.fullmatch(
                r"/index\.php/vod/play/id/\d+/sid/1/nid/\d+\.html",
                href):
            return
        self._url = urljoin(BASE_URL, href)
        self._label = []

    def handle_data(self, data):
        if self._url:
            self._label.append(data)

    def handle_endtag(self, tag):
        if tag != "a" or not self._url:
            return
        label = "".join(self._label).strip()
        if label and self._url not in self._seen:
            self.versions.append({"title": label, "url": self._url})
            self._seen.add(self._url)
        self._url = None
        self._label = []


def get_movie_versions(movie_url):
    """Return free player versions from a movie detail page."""
    if not re.fullmatch(
            rf"{re.escape(BASE_URL)}/index\.php/vod/detail/id/\d+\.html",
            movie_url):
        raise ValueError("Invalid movie detail URL")
    html = fetch_html(movie_url)
    # Restrict parsing to the regular playlist; omit the VIP playlist.
    start = html.find('id="playlistbox"')
    end = html.find('id="vplaylistbox"')
    if start < 0:
        return []
    fragment = html[start:end] if end > start else html[start:]
    parser = MovieVersionParser()
    parser.feed(fragment)
    return parser.versions
