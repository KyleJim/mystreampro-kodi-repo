"""iBaoTV catalogue provider; independent of the frozen Olevod provider."""

import re
import time
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse, quote
from urllib.request import Request, urlopen

BASE_URL = "https://ibaotv.com"
MOVIE_GENRES = {
    "drama": (0, "剧情"),
    "comedy": (0, "喜剧"),
    "action": (0, "动作"),
    "romance": (0, "爱情"),
    "thriller": (0, "惊悚"),
    "horror": (0, "恐怖"),
    "crime": (0, "犯罪"),
    "adventure": (0, "冒险"),
    "mystery": (0, "悬疑"),
    "fantasy": (0, "奇幻"),
    "sci_fi": (0, "科幻"),
    "animation": (0, "动画"),
    "family": (0, "家庭"),
    "war": (0, "战争"),
    "history": (0, "历史"),
    "costume": (0, "古装"),
    "biography": (0, "传记"),
    "lgbt": (0, "同性"),
    "sports": (0, "运动"),
    "music": (0, "音乐"),
}

MOVIE_REGIONS = (
    "中国大陆", "美国", "中国香港", "法国", "日本",
    "英国", "德国", "韩国", "加拿大", "中国台湾",
    "意大利", "西班牙", "其他",
)


TV_GENRES = {
    "tv_all": (0, "全部"),
    "tv_drama": (0, "剧情"),
    "tv_romance": (0, "爱情"),
    "tv_comedy": (0, "喜剧"),
    "tv_mystery": (0, "悬疑"),
    "tv_crime": (0, "犯罪"),
    "tv_costume": (0, "古装"),
    "tv_fantasy": (0, "奇幻"),
    "tv_thriller": (0, "惊悚"),
    "tv_lgbt": (0, "同性"),
    "tv_action": (0, "动作"),
    "tv_sci_fi": (0, "科幻"),
    "tv_family": (0, "家庭"),
    "tv_history": (0, "历史"),
    "tv_documentary": (0, "纪录片"),
    "tv_adventure": (0, "冒险"),
    "tv_horror": (0, "恐怖"),
    "tv_war": (0, "战争"),
    "tv_martial_arts": (0, "武侠"),
    "tv_biography": (0, "传记"),
    "tv_sports": (0, "运动"),
}

TV_TYPES = {
    "国产剧": 32,
    "欧美剧": 33,
    "香港剧": 34,
    "韩国剧": 35,
    "台湾剧": 36,
    "日本剧": 37,
    "海外剧": 38,
    "泰国剧": 39,
}

TV_REGIONS = tuple(TV_TYPES)



def get_dramas(category='tv_all', page=1, region=None):
    """Fetch iBaoTV series using genre and TV type filters."""
    if category not in TV_GENRES:
        raise ValueError('Unknown iBaoTV TV genre')
    if page < 1:
        raise ValueError('Invalid page')
    if region is not None and region not in TV_TYPES:
        raise ValueError('Unknown iBaoTV TV type')

    genre_label = TV_GENRES[category][1]
    genre_path = (
        '/class/' + quote(genre_label, safe='')
        if category != 'tv_all' else ''
    )
    type_id = TV_TYPES[region] if region else 2

    url = (
        f'{BASE_URL}/index.php/vod/show'
        f'{genre_path}/id/{type_id}/page/{page}.html'
    )

    request = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urlopen(request, timeout=15) as response:
        if urlparse(response.geturl()).hostname != urlparse(BASE_URL).hostname:
            raise ValueError('Unexpected iBaoTV TV redirect')
        markup = response.read().decode('utf-8', errors='replace')

    parser = CatalogueParser()
    parser.feed(markup)
    return parser.movies


class CatalogueParser(HTMLParser):
    """Parse iBaoTV catalogue cards from their poster anchor attributes.

    Poster artwork is a CSS background on an anchor, not a nested img tag.
    The card's year and video-source label are separate span elements.
    """

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.movies = []
        self._seen = set()
        self._current = None
        self._anchor_depth = 0
        self._tag_stack = []
        self._capture = None
        self._capture_depth = 0
        self._captured_text = []

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        classes = attributes.get("class", "").split()
        if tag == "a" and "myui-vodlist__thumb" in classes:
            href = attributes.get("href", "")
            if re.fullmatch(r"(?:https?://[^/]+)?/index\.php/vod/detail/id/\d+\.html", href):
                image = attributes.get("data-original", "").strip()
                if not image:
                    image = attributes.get("data-src", "").strip()
                if not image:
                    style = attributes.get("style", "")
                    match = re.search(r"background-image\s*:\s*url\(\s*['\"]?([^'\")]+)", style)
                    if match:
                        image = match.group(1).strip()
                self._current = {
                    "title": attributes.get("title", "") or attributes.get("alt", ""),
                    "url": urljoin(BASE_URL, href),
                    "image": urljoin(BASE_URL, image) if image and not image.startswith(("data:", "javascript:")) else "",
                    "rating": "", "quality": "", "year": "",
                }
                self._anchor_depth = len(self._tag_stack) + 1
        if self._current and tag == "span":
            if "pic-text" in classes:
                self._capture = "quality"
            elif "tag" in classes and "pic-tag" not in classes:
                self._capture = "year"
            if self._capture:
                self._capture_depth = len(self._tag_stack) + 1
                self._captured_text = []
        if tag not in {"img", "br", "hr", "meta", "input", "link", "source", "wbr"}:
            self._tag_stack.append(tag)

    def handle_data(self, data):
        if self._capture:
            self._captured_text.append(data)

    def handle_endtag(self, tag):
        depth = len(self._tag_stack)
        if tag == "span" and self._capture and depth == self._capture_depth:
            value = " ".join(" ".join(self._captured_text).split())
            if self._current:
                self._current[self._capture] = value
            self._capture = None
        if tag == "a" and self._current and depth == self._anchor_depth:
            if self._current["title"] and self._current["url"] not in self._seen:
                self.movies.append(self._current)
                self._seen.add(self._current["url"])
            self._current = None
            self._capture = None
        if tag in self._tag_stack:
            while self._tag_stack:
                if self._tag_stack.pop() == tag:
                    break


def get_movies(genre=None, page=1, region=None):
    """Fetch one iBaoTV movie catalogue page using verified show routes."""
    if genre is not None and genre not in MOVIE_GENRES:
        raise ValueError("Unknown iBaoTV movie genre")
    if page < 1:
        raise ValueError("Invalid page number")
    genre_path = (
        "/class/" + quote(MOVIE_GENRES[genre][1], safe="")
        if genre else ""
    )
    area_path = "/area/" + quote(region, safe="") if region else ""

    url = (
        f"{BASE_URL}/index.php/vod/show"
        f"{genre_path}{area_path}/id/1/page/{page}.html"
    )

    request = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(request, timeout=15) as response:
        final_url = response.geturl()
        if urlparse(final_url).hostname != urlparse(BASE_URL).hostname:
            raise ValueError("Unexpected iBaoTV redirect")
        content = response.read().decode("utf-8", errors="replace")
    parser = CatalogueParser()
    parser.feed(content)
    return parser.movies


class MovieDetailParser(HTMLParser):
    """Extract the visible metadata from an iBaoTV movie detail block."""

    FIELD_NAMES = {"分类": "genre", "地区": "region", "年份": "year",
                   "更新": "update", "主演": "cast", "导演": "director",
                   "简介": "plot"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.details = {key: "" for key in
                        ("title", "genre", "region", "year", "quality",
                         "cast", "director", "plot")}
        self._inside = False
        self._depth = 0
        self._capture = None
        self._capture_depth = 0
        self._text = []

    def handle_starttag(self, tag, attrs):
        classes = dict(attrs).get("class", "").split()
        if not self._inside and tag == "div" and "myui-content__detail" in classes:
            self._inside = True
            self._depth = 1
            return
        if not self._inside:
            return
        if tag == "div":
            self._depth += 1
        if self._capture is None:
            if tag == "h1" and "title" in classes:
                self._capture = "title"
            elif tag == "p" and "data" in classes:
                self._capture = "paragraph"
            if self._capture:
                self._capture_depth = 1
                self._text = []
        elif tag not in {"img", "br", "hr", "input", "meta"}:
            self._capture_depth += 1
        if self._capture and tag == "br":
            self._text.append(" ")

    def handle_data(self, data):
        if self._inside and self._capture:
            self._text.append(data)

    def handle_endtag(self, tag):
        if not self._inside:
            return
        if self._capture:
            self._capture_depth -= 1
            if self._capture_depth == 0:
                value = " ".join(" ".join(self._text).split())
                if self._capture == "title":
                    self.details["title"] = value
                elif self._capture == "paragraph":
                    for chinese, key in self.FIELD_NAMES.items():
                        if value.startswith(chinese + "：") or value.startswith(chinese + ":"):
                            result = value[len(chinese) + 1:].strip()
                            if key == "update":
                                quality = result.partition("/")[0]
                                self.details["quality"] = quality.strip()
                            elif key == "plot":
                                # The short synopsis may end in a detail-link label.
                                self.details[key] = re.sub(r"\s*详情\s*$", "", result).strip()
                            elif key == "genre":
                                # Genre, region and year share one <p> on iBaoTV.
                                parts = re.split(r"\s*(地区|年份)[：:]\s*", result)
                                self.details["genre"] = parts[0].strip()
                                for index in range(1, len(parts) - 1, 2):
                                    field = "region" if parts[index] == "地区" else "year"
                                    self.details[field] = parts[index + 1].strip()
                            else:
                                self.details[key] = result
                            break
                self._capture = None
        if tag == "div":
            self._depth -= 1
            if self._depth == 0:
                self._inside = False


def get_movie_details(url):
    """Fetch a selected iBaoTV movie's metadata without loading player links."""
    parsed = urlparse(url)
    if (parsed.scheme != "https" or parsed.hostname != "ibaotv.com"
            or not re.fullmatch(
                r"/index\.php/vod/detail/id/\d+\.html", parsed.path)):
        raise ValueError("Unexpected iBaoTV detail URL")
    request = Request(url, headers={"User-Agent": "Mozilla/5.0",
                                    "Referer": BASE_URL + "/"})
    with urlopen(request, timeout=15) as response:
        if urlparse(response.geturl()).hostname != "ibaotv.com":
            raise ValueError("Unexpected iBaoTV redirect")
        source = response.read().decode("utf-8", errors="replace")
    parser = MovieDetailParser()
    parser.feed(source)
    synopsis = FullSynopsisParser()
    synopsis.feed(source)
    if synopsis.plot:
        parser.details['plot'] = synopsis.plot
    rating = DetailRatingParser()
    rating.feed(source)
    parser.details['rating'] = rating.rating
    return parser.details




class DetailRatingParser(HTMLParser):
    """Read only the selected iBaoTV title's db-head rating."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rating = "No Rating"
        self._depth = 0
        self._head_depth = None
        self._tag_depth = None
        self._text = []
        self._found_head = False

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        classes = attributes.get("class", "").split()
        self._depth += 1

        if (tag == "div" and "db-head" in classes
                and not self._found_head):
            self._head_depth = self._depth
            self._found_head = True

        if (self._head_depth is not None
                and tag == "span"
                and "db-rate__tag" in classes):
            self._tag_depth = self._depth
            self._text = []

    def handle_data(self, data):
        if self._tag_depth is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if self._tag_depth == self._depth and tag == "span":
            value = "".join(self._text).strip()
            match = re.search(r"([0-9]+(?:\.[0-9]+)?)", value)
            if match:
                score = float(match.group(1))
                if 0 < score <= 10:
                    self.rating = f"{score:g}/10"
            self._tag_depth = None

        if self._head_depth == self._depth and tag == "div":
            self._head_depth = None

        self._depth -= 1


class FullSynopsisParser(HTMLParser):
    """Extract the complete synopsis from iBaoTV's description panel."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.plot = ""
        self._depth = 0
        self._desc_depth = None
        self._data_depth = None
        self._paragraphs = []
        self._current = []

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        classes = attributes.get("class", "").split()
        self._depth += 1

        if (tag == "div" and attributes.get("id") == "desc"
                and self._desc_depth is None):
            self._desc_depth = self._depth

        if (self._desc_depth is not None
                and self._data_depth is None
                and tag == "span" and "data" in classes):
            self._data_depth = self._depth

        if self._data_depth is not None and tag == "p":
            self._current = []

    def handle_data(self, data):
        if self._data_depth is not None:
            self._current.append(data)

    def handle_endtag(self, tag):
        if self._data_depth is not None and tag == "p":
            paragraph = " ".join(" ".join(self._current).split())
            if paragraph:
                self._paragraphs.append(paragraph)
            self._current = []

        if self._data_depth == self._depth and tag == "span":
            if self._current:
                paragraph = " ".join(" ".join(self._current).split())
                if paragraph:
                    self._paragraphs.append(paragraph)
            self.plot = "\n\n".join(self._paragraphs)
            self._data_depth = None

        if self._desc_depth == self._depth and tag == "div":
            self._desc_depth = None

        self._depth -= 1


class IBaoEpisodeParser(HTMLParser):
    """Collect unique iBaoTV episode links, excluding shortcuts."""

    def __init__(self, movie_id, episodes_only=True):
        super().__init__(convert_charrefs=True)
        self.movie_id = str(movie_id)
        self.episodes_only = episodes_only
        self.episodes = []
        self._seen = set()
        self._entry = None

    def handle_starttag(self, tag, attrs):
        if tag != 'a':
            return

        href = dict(attrs).get('href', '')
        pattern = (
            r'(?:https?://ibaotv\.com)?'
            r'/index\.php/vod/play/id/'
            + re.escape(self.movie_id)
            + r'/sid/1/nid/\d+\.html'
        )
        if not re.fullmatch(pattern, href):
            return

        self._entry = {
            'url': urljoin(BASE_URL, href),
            'label': '',
        }

    def handle_data(self, data):
        if self._entry is not None:
            self._entry['label'] += data

    def handle_endtag(self, tag):
        if tag != 'a' or self._entry is None:
            return

        entry = self._entry
        self._entry = None
        label = ' '.join(entry['label'].split())

        if not label or label == '立即播放':
            return
        if (self.episodes_only and
                not re.fullmatch(r'第\d+集', label)):
            return
        if entry['url'] in self._seen:
            return

        self._seen.add(entry['url'])
        self.episodes.append({
            'title': label,
            'url': entry['url'],
        })


def _fetch_html(url, expected_path):
    """Fetch a verified iBaoTV page without off-site redirects."""
    parsed = urlparse(url)
    if (parsed.scheme != 'https' or
            parsed.hostname != 'ibaotv.com' or
            not re.fullmatch(expected_path, parsed.path)):
        raise ValueError('Unexpected iBaoTV URL')

    request = Request(
        url,
        headers={
            'User-Agent': 'Mozilla/5.0',
            'Referer': BASE_URL + '/',
        },
    )
    with urlopen(request, timeout=15) as response:
        final = urlparse(response.geturl())
        if (final.scheme != 'https' or
                final.hostname != 'ibaotv.com'):
            raise ValueError('Unexpected iBaoTV redirect')
        return response.read().decode(
            'utf-8', errors='replace'
        )


def get_movie_versions(url, episodes_only=True):
    """Return unique iBaoTV episodes in their original page order."""
    parsed = urlparse(url)
    match = re.fullmatch(
        r'/index\.php/vod/detail/id/(\d+)\.html',
        parsed.path,
    )
    if (parsed.scheme != 'https' or
            parsed.hostname != 'ibaotv.com' or
            not match):
        raise ValueError('Unexpected iBaoTV detail URL')

    request = Request(
        url,
        headers={
            'User-Agent': 'Mozilla/5.0',
            'Referer': BASE_URL + '/',
        },
    )
    with urlopen(request, timeout=15) as response:
        final = urlparse(response.geturl())
        if (final.scheme != 'https' or
                final.hostname != 'ibaotv.com'):
            raise ValueError('Unexpected iBaoTV redirect')
        html = response.read().decode(
            'utf-8', errors='replace'
        )

    parser = IBaoEpisodeParser(
        match.group(1), episodes_only=episodes_only
    )
    parser.feed(html)
    return parser.episodes



def _resolve_hls_fallback(page_url, primary):
    """Use iBaoTV alternatives when the primary HLS playlist fails."""
    import json
    from urllib.error import HTTPError, URLError
    from urllib.parse import urlencode

    if urlparse(primary).path.lower().endswith('.m3u8') is False:
        return primary

    headers = {
        'User-Agent': 'Mozilla/5.0',
        'Referer': page_url,
    }

    def accessible(stream):
        parsed = urlparse(stream)
        if parsed.scheme != 'https' or not parsed.hostname:
            return False
        try:
            request = Request(stream, headers=headers)
            with urlopen(request, timeout=5) as response:
                content_type = response.headers.get(
                    'Content-Type', ''
                ).lower()
                sample = response.read(1024)
                return (
                    response.status == 200
                    and (
                        b'#EXTM3U' in sample
                        or 'mpegurl' in content_type
                    )
                )
        except (HTTPError, URLError, OSError, ValueError):
            return False

    if accessible(primary):
        return primary

    match = re.search(
        r'/index\.php/vod/play/id/(\d+)/sid/\d+/nid/\d+\.html',
        urlparse(page_url).path,
    )
    if not match:
        return primary

    endpoint = (
        BASE_URL + '/index.php/ajax/play_alt?'
        + urlencode({'id': match.group(1), 'u': primary})
    )

    request = Request(endpoint, headers=headers)
    try:
        with urlopen(request, timeout=8) as response:
            final = urlparse(response.geturl())
            if (final.scheme != 'https'
                    or final.hostname != 'ibaotv.com'):
                return primary
            data = json.load(response)
    except (HTTPError, URLError, OSError, ValueError,
            json.JSONDecodeError):
        return primary

    if not isinstance(data, dict):
        return primary

    if data.get('code') != 1:
        return primary

    alternatives = data.get('alts', [])
    if not isinstance(alternatives, list):
        return primary

    for alternative in alternatives[:3]:
        if not isinstance(alternative, str):
            continue
        parsed = urlparse(alternative)
        if (parsed.scheme == 'https'
                and parsed.hostname
                and parsed.path.lower().endswith('.m3u8')):
            return alternative

    return primary

def get_stream_url(url):
    """Resolve the selected iBaoTV player page to a media URL.

    The site embeds JSON in a player_aaaa JavaScript assignment. Some pages
    omit the trailing semicolon, so don't require one in the match.
    """
    import base64
    import json
    from urllib.parse import unquote

    source = _fetch_html(
        url,
        r'/index\.php/vod/play/id/\d+/sid/\d+/nid/\d+\.html',
    )
    match = re.search(r'\bplayer_aaaa\s*=\s*(\{.*?\})\s*(?:;|</script)',
                      source, re.DOTALL | re.IGNORECASE)
    if not match:
        # Avoid logging the page itself or leaking stream credentials.
        if 'player_aaaa' in source:
            raise ValueError('iBaoTV player data could not be parsed')
        if 'captcha' in source.lower() or 'cloudflare' in source.lower():
            raise ValueError('iBaoTV blocked the player page')
        raise ValueError('iBaoTV player configuration missing (page has no player_aaaa)')
    try:
        data = json.loads(match.group(1))
        value = data.get('url', '')
        encryption = int(data.get('encrypt', 0))
        if encryption == 1:
            value = unquote(value)
        elif encryption == 2:
            value = unquote(base64.b64decode(value).decode('utf-8'))
        elif encryption != 0:
            raise ValueError('Unsupported iBaoTV stream encoding')
    except (json.JSONDecodeError, TypeError, UnicodeDecodeError) as exc:
        raise ValueError('Invalid iBaoTV player data') from exc
    parsed = urlparse(value)
    if parsed.scheme not in ('https', 'http') or not parsed.hostname:
        raise ValueError('Invalid iBaoTV stream URL')
    return _resolve_hls_fallback(url, value)
