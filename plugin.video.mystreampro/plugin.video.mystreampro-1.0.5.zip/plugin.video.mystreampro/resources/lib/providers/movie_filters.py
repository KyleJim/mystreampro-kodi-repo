"""Read movie filter labels and values from provider catalogue markup."""

import re
from html.parser import HTMLParser
from urllib.parse import unquote, urlparse


class FilterParser(HTMLParser):
    """Collect labelled filter rows and their actual website anchor URLs."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.depth = 0
        self.rows = []
        self.stack = []
        self.anchor = None
        self.anchor_depth = 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in ('img', 'br', 'hr', 'meta', 'input', 'link', 'source', 'wbr'):
            return
        self.depth += 1
        if tag in ('ul', 'div'):
            self.stack.append({'tag': tag, 'depth': self.depth,
                               'class': attrs.get('class', ''), 'text': [], 'links': []})
        if tag == 'a' and self.stack:
            self.anchor = {'href': attrs.get('href', ''), 'text': []}
            self.anchor_depth = self.depth

    def handle_data(self, data):
        if self.anchor is not None:
            self.anchor['text'].append(data)
        for row in self.stack:
            row['text'].append(data)

    def handle_endtag(self, tag):
        if tag == 'a' and self.anchor is not None and self.anchor_depth == self.depth:
            label = ''.join(self.anchor['text']).strip()
            if label:
                for row in self.stack:
                    row['links'].append((label, self.anchor['href']))
            self.anchor = None
        if tag in ('ul', 'div'):
            for i in range(len(self.stack) - 1, -1, -1):
                if self.stack[i]['depth'] == self.depth and self.stack[i]['tag'] == tag:
                    self.rows.append(self.stack.pop(i))
                    break
        self.depth = max(0, self.depth - 1)


def parse_filters(markup, provider):
    """Return (ordered genre tuples, ordered region names) from filter rows."""
    parser = FilterParser()
    parser.feed(markup)
    genres, regions = [], []
    for row in parser.rows:
        if row['tag'] != 'ul':
            continue
        cls = row['class'].lower()
        if not ('screen' in cls or 'filter' in cls or '筛选' in ''.join(row['text'][:3])):
            continue
        raw = ''.join(row['text']).strip()
        # The category name precedes its anchor options in each catalogue row.
        first_label = row['links'][0][0] if row['links'] else ''
        prefix = raw.split(first_label, 1)[0].strip() if first_label else ''
        is_genre = any(word in prefix for word in ('分类', '类型'))
        is_region = '地区' in prefix
        if not (is_genre or is_region):
            continue
        for label, href in row['links']:
            if label in ('全部', '重置'):
                continue
            path = unquote(urlparse(href).path)
            if is_genre:
                # Both providers use numeric movie type IDs in their show URLs.
                match = re.search(r'/(?:id/|show/|type/)(\d+)(?:[/.]|$)', path)
                if match and int(match.group(1)) > 1:
                    pair = (str(int(match.group(1))), label)
                    if pair not in genres:
                        genres.append(pair)
            elif is_region:
                match = re.search(r'/area/([^/.]+)', path)
                if match and label not in regions:
                    regions.append(label)
    if not genres or not regions:
        flat_genres, flat_regions = parse_flat_filters(markup)
        genres = genres or flat_genres
        regions = regions or flat_regions
    return genres, regions


class FlatFilterParser(HTMLParser):
    """Fallback for filter menus built from divs instead of ul rows."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.section = None
        self.anchor = None
        self.entries = {'genre': [], 'region': []}

    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.anchor = [dict(attrs).get('href', ''), []]

    def handle_data(self, data):
        label = data.strip().strip('：:')
        if label in ('类型', '分类'):
            self.section = 'genre'
        elif label == '地区':
            self.section = 'region'
        elif label in ('年份', '排序', '时间', '频道'):
            self.section = None
        if self.anchor is not None:
            self.anchor[1].append(data)

    def handle_endtag(self, tag):
        if tag == 'a' and self.anchor is not None:
            label = ''.join(self.anchor[1]).strip()
            if self.section and label and label not in ('全部', '重置'):
                self.entries[self.section].append((label, self.anchor[0]))
            self.anchor = None

def parse_flat_filters(markup):
    parser = FlatFilterParser()
    parser.feed(markup)
    genres, regions = [], []
    for label, href in parser.entries['genre']:
        path = unquote(urlparse(href).path)
        match = re.search(r'/(?:show/|id/|type/)(\d+)(?:[/.]|$)', path)
        if match and int(match.group(1)) > 1:
            pair = (str(int(match.group(1))), label)
            if pair not in genres:
                genres.append(pair)
    for label, href in parser.entries['region']:
        path = unquote(urlparse(href).path)
        if re.search(r'/area/[^/.]+', path) and label not in regions:
            regions.append(label)
    return genres, regions
