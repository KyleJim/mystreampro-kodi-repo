"""Persistent non-UI Kodi service for playback bookmarks.

Never holds open a plugin request or a modal window during video playback.
"""
import json
import os
import sqlite3
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROPERTY = 'MyStreamProV1.PlayRequest'
ADDON_ID = 'plugin.video.mystreampro'
RETURN_PROPERTY = 'MyStreamProV1.ReturnRequest'


def db():
    folder = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    os.makedirs(folder, exist_ok=True)
    connection = sqlite3.connect(os.path.join(folder, 'details.sqlite3'), timeout=5)
    connection.execute('CREATE TABLE IF NOT EXISTS playback '
                       '(movie_url TEXT PRIMARY KEY, position REAL, duration REAL, updated INTEGER)')
    return connection


def save(movie_url, position, duration, completed=False):
    if not movie_url:
        return
    try:
        with db() as connection:
            if completed or position < 30 or (duration > 0 and position >= duration - 90):
                connection.execute('DELETE FROM playback WHERE movie_url=?', (movie_url,))
            else:
                connection.execute('INSERT OR REPLACE INTO playback '
                    '(movie_url,position,duration,updated) VALUES(?,?,?,?)',
                    (movie_url, position, duration, int(time.time())))
    except (sqlite3.Error, OSError) as exc:
        xbmc.log('MyStreamPro M4.7 save: %s' % exc, xbmc.LOGWARNING)


class BookmarkPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.movie_url = ''
        self.resume = 0
        self.position = 0
        self.duration = 0
        self.seek_pending = False
        self.started = False
        self.request_received_at = 0
        self.page = 1
        self.index = 0
        self.category = 'movies'
        self.source = 'olevod'
        self.region = None
        self.episode = -1
        self.return_pending = 0
        self.m2e3_stop_at = 0
        self.return_generation = 0
        self.playback_generation = 0
        self.restore_not_before = 0
        self.live_urls = []
        self.live_attempt = 0
        self.m3e3_failed_start = False
        self.m3e4_waiting_for_ack = False

    def accept_request(self, request):
        self.playback_generation += 1
        self.m3e3_failed_start = False
        self.m3e4_waiting_for_ack = False
        self.return_pending = 0
        self.restore_not_before = 0
        self.movie_url = request['movie_url']
        self.live_urls = request.get('live_urls', [])
        self.live_attempt = 0
        xbmc.log('MyStreamPro M4.7 DIAG: service accepted playback request', xbmc.LOGWARNING)
        self.page = max(1, int(request.get('page', 1)))
        self.index = max(0, int(request.get('index', 0)))
        self.category = request.get('category', 'movies')
        self.source = request.get('source', 'olevod')
        self.region = request.get('region') or None
        self.episode = int(request.get('episode', -1))
        self.return_pending = 0
        self.resume = float(request.get('resume', 0) or 0)
        self.position = 0
        self.duration = 0
        self.seek_pending = self.resume >= 30 and self.source != 'livetv'
        self.started = False
        self.request_received_at = time.monotonic()

    def onAVStarted(self):
        if not self.movie_url:
            return
        self.started = True
        self.m3e3_failed_start = False
        self.m3e4_waiting_for_ack = False
        self.return_pending = 0
        self.request_received_at = 0
        xbmc.log('MyStreamPro M4.7 DIAG: AV started', xbmc.LOGWARNING)
        if self.seek_pending:
            # Kodi's player is now active; seeking in the plugin itself would
            # block or race with the player opening.
            try:
                self.seekTime(self.resume)
                self.position = self.resume
                self.seek_pending = False
            except (RuntimeError, ValueError) as exc:
                xbmc.log('MyStreamPro M4.7 seek: %s' % exc, xbmc.LOGWARNING)

    def onPlayBackStopped(self):
        log_m3e2_windows('stopped')
        self.m2e3_stop_at = time.monotonic()
        xbmc.log('MSP M2-E4 TIMING playback_stopped', xbmc.LOGWARNING)
        if self.source == 'livetv' and self.movie_url and not self.started and self.live_attempt + 1 < len(self.live_urls):
            self.live_attempt += 1
            self.return_pending = -self.live_attempt
            self.request_received_at = 0
            return
        xbmc.log('MyStreamPro M4.7 DIAG: playback stopped started=%s position=%.1f' % (self.started, self.position), xbmc.LOGWARNING)
        if self.movie_url and self.source != 'livetv' and not self.started:
            self.m3e3_failed_start = True
        if self.movie_url:
            if self.source != 'livetv' and self.started:
                save(self.movie_url, self.position, self.duration)
            self.return_pending = time.monotonic() + 0.25
            self.return_generation = self.playback_generation
        self.movie_url = ''
        self.started = False
        self.request_received_at = 0

    def onPlayBackEnded(self):
        log_m3e2_windows('ended')
        xbmc.log('MyStreamPro M4.7 DIAG: playback ended naturally started=%s position=%.1f' %
                 (self.started, self.position), xbmc.LOGWARNING)
        if self.movie_url:
            if self.source != 'livetv' and self.started:
                save(self.movie_url, self.position, self.duration, completed=True)
            self.return_pending = time.monotonic() + 0.25
            self.return_generation = self.playback_generation
        self.movie_url = ''
        self.started = False
        self.request_received_at = 0

    def onPlayBackError(self):
        log_m3e2_windows('error')
        # A failed stream may never trigger onPlayBackStopped or onAVStarted.
        xbmc.log('MyStreamPro M4.8.3: playback error; restoring browser', xbmc.LOGWARNING)
        if self.movie_url and self.source != 'livetv' and not self.started:
            self.m3e3_failed_start = True
        if self.movie_url and self.source == 'livetv' and self.live_attempt + 1 < len(self.live_urls):
            self.live_attempt += 1
            self.started = False
            self.request_received_at = 0
            self.return_pending = -self.live_attempt
            return
        if self.movie_url:
            self.return_pending = time.monotonic() + 0.25
            self.return_generation = self.playback_generation
        self.movie_url = ''
        self.started = False
        self.request_received_at = 0


def log_m3e2_windows(stage):
    # Diagnostic only: do not change Kodi windows or dialog state.
    try:
        window_id = xbmcgui.getCurrentWindowId()
        dialog_id = xbmcgui.getCurrentWindowDialogId()
        xbmc.log(
            'MSP M3-E2 stage=%s window=%s dialog=%s' %
            (stage, window_id, dialog_id),
            xbmc.LOGWARNING)
    except (RuntimeError, AttributeError) as exc:
        xbmc.log('MSP M3-E2 stage=%s lookup_failed=%s' %
                 (stage, exc), xbmc.LOGWARNING)


monitor = xbmc.Monitor()
player = BookmarkPlayer()
window = xbmcgui.Window(10000)
xbmc.log('MyStreamPro M4.7 DIAG: service started', xbmc.LOGWARNING)
last_request = 0
last_return_request = 0
last_category_request = 0
last_save = 0
while not monitor.abortRequested():
    raw = window.getProperty(PROPERTY)
    if raw:
        try:
            request = json.loads(raw)
            created = float(request.get('created', 0))
            if created > last_request and time.time() - created < 90:
                last_request = created
                xbmc.log('MyStreamPro M4.7 DIAG: request received', xbmc.LOGWARNING)
                player.accept_request(request)
            window.clearProperty(PROPERTY)
        except (ValueError, KeyError, TypeError) as exc:
            xbmc.log('MyStreamPro M4.7 request: %s' % exc, xbmc.LOGWARNING)
            window.clearProperty(PROPERTY)
    category_raw = window.getProperty('MyStreamProV1.CategoryNavRequest')
    if category_raw:
        window.clearProperty('MyStreamProV1.CategoryNavRequest')
        try:
            category_req = json.loads(category_raw)
            created = float(category_req.get('created', 0))
            if (created > last_category_request and time.time() - created < 90
                    and not player.movie_url and not player.isPlaying()):
                last_category_request = created
                # Kodi's normal directory view, not a replacement category dialog.
                # A Container.Update from home should put home in Back history.
                root_uri = 'plugin://' + ADDON_ID + '/'
                categories_uri = root_uri + '?source=olevod&kind=tv'
                xbmc.log('MyStreamPro M4.7 DIAG: seed Kodi home -> categories history', xbmc.LOGWARNING)
                xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % root_uri)
                xbmc.sleep(500)
                xbmc.executebuiltin('Container.Update("%s")' % categories_uri)
        except (ValueError, TypeError, KeyError) as exc:
            xbmc.log('MyStreamPro M4.7 DIAG: category navigation error %s' % exc, xbmc.LOGWARNING)
    # The TV episode picker is a modal opened by a plugin directory call.
    # Restore its poster grid only after the picker has closed and the
    # original plugin call has had time to finish.
    tv_raw = window.getProperty('MyStreamProV1.TvPosterNavRequest')
    if tv_raw:
        window.clearProperty('MyStreamProV1.TvPosterNavRequest')
        try:
            tv_req = json.loads(tv_raw)
            created = float(tv_req.get('created', 0))
            if (time.time() - created < 90 and not player.movie_url
                    and not player.isPlaying()):
                from urllib.parse import urlencode
                root_uri = 'plugin://' + ADDON_ID + '/'
                poster_uri = root_uri + '?' + urlencode({
                    'source': tv_req['source'], 'kind': 'tv',
                    'category': tv_req['category'],
                    'page': tv_req['page'], 'index': tv_req['index'],
                    'region': tv_req.get('region', ''),
                })
                xbmc.log('MyStreamPro M1: deferred TV posters %s' %
                         poster_uri, xbmc.LOGWARNING)
                xbmc.executebuiltin(
                    'ActivateWindow(Videos,"%s",return)' % root_uri)
                # M2-E8: shorten only the deferred TV root-seeding wait.
                # Keep root activation and the Back stack intact.
                xbmc.sleep(75)
                xbmc.log(
                    'MSP M2-E8 TIMING tv_poster_update '
                    'request_to_update_ms=%.1f' %
                    ((time.time() - created) * 1000),
                    xbmc.LOGWARNING)
                xbmc.executebuiltin('Container.Update("%s")' % poster_uri)
        except (ValueError, TypeError, KeyError) as exc:
            xbmc.log('MyStreamPro M1: TV poster return error %s' % exc,
                     xbmc.LOGWARNING)
    cancel_raw = window.getProperty(RETURN_PROPERTY)
    if cancel_raw:
        window.clearProperty(RETURN_PROPERTY)
        try:
            cancel = json.loads(cancel_raw)
            created = float(cancel.get('created', 0))
            if (created > last_return_request and time.time() - created < 90
                    and not player.movie_url and not player.isPlaying()):
                last_return_request = created
                player.page = max(1, int(cancel.get('page', 1)))
                player.index = max(0, int(cancel.get('index', 0)))
                player.category = cancel.get('category', 'movies')
                player.source = cancel.get('source', 'olevod')
                player.region = cancel.get('region') or None
                player.episode = int(cancel.get('episode', -1))
                player.return_pending = time.monotonic() + 1.0
                xbmc.log('MyStreamPro M4.7 DIAG: cancel return accepted reason=%s' %
                         cancel.get('reason', ''), xbmc.LOGWARNING)
        except (ValueError, TypeError, KeyError) as exc:
            xbmc.log('MyStreamPro M4.7 DIAG: cancel return error: %s' % exc, xbmc.LOGWARNING)
    if player.movie_url and player.isPlayingVideo():
        try:
            player.position = player.getTime()
            player.duration = player.getTotalTime()
            if player.seek_pending and player.started:
                player.seekTime(player.resume)
                player.position = player.resume
                player.seek_pending = False
            if player.source != 'livetv' and time.time() - last_save >= 5:
                save(player.movie_url, player.position, player.duration)
                xbmc.log('MyStreamPro M4.7 DIAG: progress saved position=%.1f duration=%.1f' % (player.position, player.duration), xbmc.LOGWARNING)
                last_save = time.time()
        except (RuntimeError, ValueError):
            pass
    # Some unsupported or dead streams never fire a playback callback.
    # Wait for Kodi to start AV; on timeout restore the exact browsing state.
    if (player.movie_url and not player.started and player.request_received_at
            and time.monotonic() - player.request_received_at >= 20
            and not player.isPlaying()):
        xbmc.log('MyStreamPro M4.8.3: playback start timeout', xbmc.LOGWARNING)
        if player.source == 'livetv' and player.live_attempt + 1 < len(player.live_urls):
            player.live_attempt += 1
            player.return_pending = -player.live_attempt
        else:
            player.movie_url = ''
            player.return_pending = time.monotonic() + 1.0
        player.request_received_at = 0
    # Retry a failed live stream, but never retry an intentional Stop.
    if player.source == 'livetv' and player.return_pending < 0 and not player.isPlaying():
        player.return_pending = 0
        try:
            stream = player.live_urls[player.live_attempt]
            item = xbmcgui.ListItem(path=stream)
            item.setProperty('IsPlayable', 'true')
            player.started = False
            player.request_received_at = time.monotonic()
            xbmc.Player().play(stream, item)
        except (RuntimeError, ValueError, IndexError) as exc:
            xbmc.log('MyStreamPro Live TV backup failed: %s' % exc, xbmc.LOGWARNING)
            player.movie_url = ''
            player.return_pending = time.monotonic() + 1.0
    # Reopen browser from the background service only AFTER playback stops.
    # Never keep the plugin or a modal dialog alive during video playback.
    if (player.return_pending > 0
            and time.monotonic() >= player.return_pending
            and not player.movie_url and not player.isPlaying()):
        # Leave Kodi's native error dialog visible until the user presses OK.
        # Keep the pending return alive so the browser cannot cover the dialog.
        if player.m3e3_failed_start and player.source != 'livetv':
            dialog_id = xbmcgui.getCurrentWindowDialogId()
            if dialog_id == 12002:
                if not player.m3e4_waiting_for_ack:
                    xbmc.log('MSP M3-E4 waiting for user OK',
                             xbmc.LOGWARNING)
                player.m3e4_waiting_for_ack = True
                continue
            if player.m3e4_waiting_for_ack:
                xbmc.log('MSP M3-E4 OK acknowledged; restoring browser',
                         xbmc.LOGWARNING)
        player.return_pending = 0
        player.m3e4_waiting_for_ack = False
        player.m3e3_failed_start = False
        log_m3e2_windows('before_restore')
        xbmc.log('MSP M2-E6 restore guarded generation=%s' %
                 player.playback_generation, xbmc.LOGWARNING)
        xbmc.log('MSP M2-E4 TIMING restore_dispatch stop_to_dispatch_ms=%.1f' %
                 ((time.monotonic() - player.m2e3_stop_at) * 1000
                  if player.m2e3_stop_at else -1), xbmc.LOGWARNING)
        if True:
            from urllib.parse import urlencode
            uri = 'plugin://' + ADDON_ID + '/?' + urlencode({
                'source': player.source,
                'kind': 'movies' if player.category.startswith('movies') else 'tv',
                'category': (player.category.split(':', 1)[1] if ':' in player.category else '') if player.category.startswith('movies') else player.category,
                'page': player.page, 'index': player.index,
                'region': player.region or '', 'episode': player.episode})
            xbmc.log('MyStreamPro M4.7 DIAG: return attempt uri=%s' % uri, xbmc.LOGWARNING)
            # Restore the real plugin root as the parent before opening the
            # modal poster browser. ActivateWindow directly to the poster URI
            # loses its parent directory on some Kodi/LibreELEC versions.
            root_uri = 'plugin://' + ADDON_ID + '/'
            xbmc.executebuiltin(
                'ActivateWindow(Videos,"%s",return)' % root_uri)
            xbmc.sleep(150)
            xbmc.log('MSP M2-E4 TIMING root_to_update_ms=%.1f' %
                     ((time.monotonic() - player.m2e3_stop_at) * 1000
                      if player.m2e3_stop_at else -1), xbmc.LOGWARNING)
            xbmc.executebuiltin('Container.Update("%s")' % uri)
    if monitor.waitForAbort(0.1):
        break
if player.movie_url and player.started and player.source != 'livetv':
    save(player.movie_url, player.position, player.duration)
